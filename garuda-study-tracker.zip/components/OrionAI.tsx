
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Type, FunctionDeclaration } from '@google/genai';
import { Subject, UserStats } from '../types';
import OrionLogo from './OrionLogo';

interface Message {
  role: 'user' | 'model';
  text: string;
  image?: string;
  sources?: any[];
}

interface OrionAIProps {
  subjects: Subject[];
  userStats: UserStats;
  onToggleChapter?: (subjectId: string, chapterId: string) => void;
  onNavigate?: (tab: string) => void;
  initialPrompt?: string;
  autoStartVoice?: boolean;
  onVoiceStarted?: () => void;
  onVoiceStatusChange?: (isActive: boolean) => void;
}

function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const OrionAI: React.FC<OrionAIProps> = ({ subjects, userStats, onToggleChapter, onNavigate, initialPrompt, autoStartVoice, onVoiceStarted, onVoiceStatusChange }) => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: '### **Namaste Arnav!**\n\nI am **Orion**, your Garuda Study Intelligence. I am now deeply synced with your **PW (Physics Wallah)** curriculum and batch goals. How can I assist your prep today?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [voiceTranscription, setVoiceTranscription] = useState('');
  const [isListeningForWakeWord, setIsListeningForWakeWord] = useState(false);
  
  const sessionRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const audioContextsRef = useRef<{ input?: AudioContext; output?: AudioContext }>({});
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const recognitionRef = useRef<any>(null);

  const SYSTEM_PROMPT = `You are Orion, the Elite Neural Mentor for Arnav Singh.
  
  CORE MISSION:
  1. Deep knowledge of Physics Wallah (PW) teaching methods, batch structures (Lakshya, Arjuna), and Module patterns.
  2. Use grounded search to verify JEE/Board schedules and PW-specific announcements.
  3. Respond as a PW-integrated study assistant.
  4. CRITICAL: Your responses must be highly structured. Use clear headings (###), bold key terms (**term**), bullet points for definitions, and numbered lists for steps. 
  5. STYLE: Maintain a "High-Value Mentor" vibe—authoritative, precise, and encouraging. Use professional terminology.
  6. FORMATTING: Always start with a brief high-level summary, then use points/definitions for details. Highlight main focused topics using bold.
  
  USER CONTEXT:
  - Student: Arnav Singh
  - PW Batch: ${userStats.selectedBatch}
  - App: Garuda Neural Engine`;

  const [currentModelResponse, setCurrentModelResponse] = useState('');

  const executeSendMessage = async (userMessage: string) => {
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `User Request: ${userMessage}`,
        config: {
          systemInstruction: SYSTEM_PROMPT,
          tools: [{ googleSearch: {} }]
        }
      });

      const grounding = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      setMessages(prev => [...prev, { 
        role: 'model', 
        text: response.text || '', 
        sources: grounding 
      }]);
    } catch (error: any) {
      setMessages(prev => [...prev, { role: 'model', text: "Neural connection disrupted. Please re-engage." }]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (initialPrompt && initialPrompt !== '') {
      executeSendMessage(initialPrompt);
    }
  }, [initialPrompt]);

  const stopVoiceSession = () => {
    if (sessionRef.current) {
      try { sessionRef.current.close(); } catch (e) {}
      sessionRef.current = null;
    }
    
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }

    if (audioContextsRef.current.input) {
      try { audioContextsRef.current.input.close(); } catch (e) {}
    }
    if (audioContextsRef.current.output) {
      try { audioContextsRef.current.output.close(); } catch (e) {}
    }
    audioContextsRef.current = {};
    
    sourcesRef.current.forEach(source => {
      try { source.stop(); } catch (e) {}
    });
    sourcesRef.current.clear();
    
    nextStartTimeRef.current = 0;
    setIsVoiceActive(false);
    if (onVoiceStatusChange) onVoiceStatusChange(false);
    setVoiceTranscription('');
    setCurrentModelResponse('');
  };

  const startVoiceSession = async () => {
    // Stop wake word detection while session is active
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }

    try {
      setIsVoiceActive(true);
      if (onVoiceStatusChange) onVoiceStatusChange(true);
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const inputAudioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputAudioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextsRef.current = { input: inputAudioCtx, output: outputAudioCtx };

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: () => {
            const source = inputAudioCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioCtx.createScriptProcessor(4096, 1, 1);
            processorRef.current = scriptProcessor;

            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) {
                int16[i] = Math.max(-1, Math.min(1, inputData[i])) * 32767;
              }
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              sessionPromise.then(s => {
                if (s) s.sendRealtimeInput({ media: pcmBlob });
              });
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioCtx.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(source => {
                try { source.stop(); } catch (e) {}
              });
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
              setCurrentModelResponse('');
            }

            // Handle Transcriptions
            const userText = message.serverContent?.inputTranscription?.text;
            if (userText) {
              setVoiceTranscription(prev => prev + " " + userText);
            }

            const modelParts = message.serverContent?.modelTurn?.parts;
            if (modelParts) {
              for (const part of modelParts) {
                if (part.text) {
                  setCurrentModelResponse(prev => prev + part.text);
                }
                if (part.inlineData?.data) {
                  const base64Audio = part.inlineData.data;
                  nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioCtx.currentTime);
                  const audioBuffer = await decodeAudioData(decode(base64Audio), outputAudioCtx, 24000, 1);
                  const source = outputAudioCtx.createBufferSource();
                  source.buffer = audioBuffer;
                  source.connect(outputAudioCtx.destination);
                  
                  source.onended = () => {
                    sourcesRef.current.delete(source);
                  };
                  sourcesRef.current.add(source);
                  
                  source.start(nextStartTimeRef.current);
                  nextStartTimeRef.current += audioBuffer.duration;
                }
              }
            }

            // If a turn is complete, we commit the transcript to messages
            if (message.serverContent?.turnComplete) {
              setMessages(prev => {
                const newMessages = [...prev];
                if (voiceTranscription.trim()) {
                  newMessages.push({ role: 'user', text: voiceTranscription.trim() });
                }
                if (currentModelResponse.trim()) {
                  newMessages.push({ role: 'model', text: currentModelResponse.trim() });
                }
                return newMessages;
              });
              setVoiceTranscription('');
              setCurrentModelResponse('');
            }
          },
          onerror: (e) => stopVoiceSession(),
          onclose: (e) => stopVoiceSession(),
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
          },
          systemInstruction: SYSTEM_PROMPT,
          inputAudioTranscription: {},
          outputAudioTranscription: {},
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err) {
      stopVoiceSession();
    }
  };

  useEffect(() => {
    if (autoStartVoice && !isVoiceActive) {
      startVoiceSession();
      if (onVoiceStarted) onVoiceStarted();
    }
  }, [autoStartVoice, isVoiceActive]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    const userMessage = input.trim();
    setInput('');
    executeSendMessage(userMessage);
  };

  const parseLine = (line: string) => {
    const parts = line.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="text-indigo-600 font-black bg-indigo-50 dark:bg-indigo-900/20 px-1 rounded border border-indigo-100 dark:border-indigo-800/50 shadow-sm">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  const renderMessageContent = (msg: Message) => {
    const lines = msg.text.split('\n');
    return (
      <div className="space-y-4">
        {lines.map((line, i) => {
          const trimmed = line.trim();
          if (trimmed.startsWith('###')) {
            return (
              <h3 key={i} className="text-lg font-black uppercase tracking-tighter text-slate-900 dark:text-white mt-8 mb-4 border-l-4 border-indigo-600 pl-4 bg-slate-50 dark:bg-slate-800/50 py-2 rounded-r-lg">
                {trimmed.replace(/###/g, '').trim()}
              </h3>
            );
          }
          if (trimmed.startsWith('-') || trimmed.startsWith('*')) {
            return (
              <div key={i} className="flex gap-4 ml-2 group">
                <div className="w-2 h-2 rounded-full bg-indigo-500 mt-2 flex-shrink-0 group-hover:scale-125 transition-transform"></div>
                <p className="text-sm font-medium text-slate-700 dark:text-slate-300 leading-relaxed">{parseLine(line.substring(1).trim())}</p>
              </div>
            );
          }
          if (/^\d+\./.test(trimmed)) {
            return (
              <div key={i} className="flex gap-4 ml-2 group">
                <span className="text-xs font-black text-indigo-600 mt-1 bg-indigo-50 dark:bg-indigo-900/30 w-6 h-6 flex items-center justify-center rounded-full flex-shrink-0">{trimmed.match(/^\d+/)?.[0]}</span>
                <p className="text-sm font-medium text-slate-700 dark:text-slate-300 leading-relaxed">{parseLine(line.replace(/^\d+\./, '').trim())}</p>
              </div>
            );
          }
          if (trimmed === '') return <div key={i} className="h-2" />;
          return <p key={i} className="mb-3 leading-relaxed text-sm font-medium text-slate-700 dark:text-slate-300">{parseLine(line)}</p>;
        })}
      </div>
    );
  };

  return (
    <div className="w-full max-w-5xl mx-auto flex flex-col pb-32">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2.5rem] p-6 flex items-center justify-between shadow-sm mb-8">
        <div className="flex items-center gap-5">
          <div className="relative">
            <OrionLogo className="w-16 h-16" />
            {isVoiceActive && <div className="absolute -top-1 -right-1 w-4 h-4 bg-indigo-500 rounded-full animate-ping"></div>}
          </div>
          <div>
            <h3 className="text-lg font-black text-slate-900 dark:text-white uppercase tracking-tighter leading-none mb-1.5">Orion Neural Interface</h3>
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${isVoiceActive ? 'bg-indigo-500 animate-pulse' : isListeningForWakeWord ? 'bg-amber-500 animate-pulse' : 'bg-green-500'}`}></span>
              <span className="text-[11px] font-black text-slate-500 uppercase tracking-[0.2em]">
                {isVoiceActive ? 'Neural Link Established' : isListeningForWakeWord ? 'Listening for "Orion"' : 'System Online'}
              </span>
            </div>
          </div>
        </div>
        <button 
          onClick={isVoiceActive ? stopVoiceSession : startVoiceSession}
          className={`px-6 py-3 rounded-2xl flex items-center gap-3 font-black text-[11px] uppercase tracking-widest transition-all shadow-lg ${
            isVoiceActive ? 'bg-red-500 text-white hover:bg-red-600' : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-600/20'
          }`}
        >
          <i className={`fa-solid ${isVoiceActive ? 'fa-phone-slash' : 'fa-headset'}`}></i>
          {isVoiceActive ? 'Terminate Link' : 'Initialize Voice'}
        </button>
      </div>

      <div className="space-y-10 px-4 md:px-0">
        {isVoiceActive && (
          <div className="animate-in fade-in slide-in-from-top-6 duration-700">
            <div className="bg-slate-900 border border-slate-800 rounded-[3rem] overflow-hidden shadow-2xl">
              <div className="bg-indigo-600 px-8 py-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <i className="fa-solid fa-brain text-white animate-pulse"></i>
                  <h4 className="text-[11px] font-black uppercase tracking-[0.3em] text-white">Live Neural Transcript</h4>
                </div>
                <div className="flex gap-1.5">
                  <div className="w-1.5 h-1.5 bg-white/40 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                  <div className="w-1.5 h-1.5 bg-white/60 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                  <div className="w-1.5 h-1.5 bg-white rounded-full animate-bounce"></div>
                </div>
              </div>
              
              <div className="p-10 grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="space-y-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-2 h-2 rounded-full bg-slate-500"></div>
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">User Input</p>
                  </div>
                  <div className="min-h-[150px] bg-slate-800/50 border border-slate-700 p-6 rounded-3xl">
                    {voiceTranscription ? (
                      <p className="text-base font-bold text-slate-300 italic leading-relaxed">"{voiceTranscription}"</p>
                    ) : (
                      <div className="h-full flex items-center justify-center">
                        <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest animate-pulse">Awaiting Signal...</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-2 h-2 rounded-full bg-indigo-500"></div>
                    <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Orion Response</p>
                  </div>
                  <div className="min-h-[150px] bg-indigo-600/5 border border-indigo-500/20 p-6 rounded-3xl">
                    {currentModelResponse ? (
                      <div className="text-slate-200">
                        {renderMessageContent({ role: 'model', text: currentModelResponse })}
                      </div>
                    ) : (
                      <div className="h-full flex items-center justify-center">
                        <p className="text-[10px] font-black text-indigo-900/50 uppercase tracking-widest animate-pulse">Processing Neural Data...</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="space-y-10">
          {messages.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-4 duration-500`}>
              <div className={`max-w-[90%] p-8 rounded-[2.5rem] shadow-sm relative ${
                msg.role === 'user' 
                  ? 'bg-indigo-600 text-white rounded-tr-none shadow-indigo-600/10' 
                  : 'bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-800 rounded-tl-none'
              }`}>
                <div className={`absolute -top-3 ${msg.role === 'user' ? '-right-2' : '-left-2'} px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${
                  msg.role === 'user' ? 'bg-slate-900 text-white' : 'bg-indigo-600 text-white'
                }`}>
                  {msg.role === 'user' ? 'Arnav Singh' : 'Orion AI'}
                </div>
                {renderMessageContent(msg)}
              </div>
            </div>
          ))}
        </div>
        
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-8 py-5 rounded-[2rem] flex items-center gap-4 shadow-sm">
              <div className="flex gap-1">
                <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce"></div>
              </div>
              <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-500">Neural Synthesis In Progress</span>
            </div>
          </div>
        )}
      </div>

      <div className="fixed bottom-8 left-0 right-0 z-50 px-6 md:px-0">
        <div className="max-w-4xl mx-auto bg-white/90 dark:bg-slate-900/90 backdrop-blur-2xl border border-slate-200 dark:border-slate-800 rounded-[3rem] p-4 shadow-2xl shadow-indigo-600/10">
          <form onSubmit={handleSendMessage} className="relative flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400">
              <i className="fa-solid fa-bolt-lightning"></i>
            </div>
            <input 
              type="text" 
              value={input} 
              onChange={(e) => setInput(e.target.value)} 
              placeholder="Command Orion: Modules, Strategy, or Backlog..." 
              className="flex-1 bg-transparent border-none focus:ring-0 text-sm font-bold placeholder:text-slate-400 dark:placeholder:text-slate-600" 
            />
            <button 
              type="submit" 
              disabled={isLoading || !input.trim()}
              className="w-14 h-14 bg-indigo-600 text-white rounded-2xl flex items-center justify-center shadow-xl shadow-indigo-600/30 hover:scale-105 active:scale-95 transition-all disabled:opacity-50 disabled:scale-100"
            >
              <i className="fa-solid fa-paper-plane"></i>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default OrionAI;
