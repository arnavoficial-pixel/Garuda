
import React, { useState } from 'react';

const TestSeries: React.FC = () => {
  const quizUrl = "https://gemini.google.com/share/56714cd91ecb";
  const [isIframeLoading, setIsIframeLoading] = useState(true);

  return (
    <div className="w-full max-w-6xl mx-auto py-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2.5rem] overflow-hidden shadow-2xl transition-all">
        {/* Header */}
        <div className="bg-gradient-to-br from-[#D11217] to-[#8a0c10] p-8 md:p-12 text-white relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <i className="fa-solid fa-file-signature text-[15rem] absolute -bottom-10 -right-10 rotate-12"></i>
          </div>
          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <h2 className="text-3xl md:text-5xl font-black tracking-tighter uppercase mb-2">Garuda Test Series</h2>
              <p className="text-white/70 font-bold text-xs uppercase tracking-[0.3em]">Neural Evaluation Protocol • Batch 2026</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="px-5 py-3 bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 text-center">
                <p className="text-[8px] font-black uppercase tracking-widest text-white/60 mb-1">Status</p>
                <p className="text-sm font-black uppercase flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span> Live
                </p>
              </div>
              <div className="px-5 py-3 bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 text-center">
                <p className="text-[8px] font-black uppercase tracking-widest text-white/60 mb-1">Type</p>
                <p className="text-sm font-black uppercase">Board Pattern</p>
              </div>
            </div>
          </div>
        </div>

        {/* Orion's Briefing */}
        <div className="bg-slate-50 dark:bg-slate-800/30 p-6 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#D11217] to-[#FFB800] flex-shrink-0 flex items-center justify-center text-white shadow-md">
              <i className="fa-solid fa-brain-circuit text-lg"></i>
            </div>
            <div>
              <p className="text-[10px] font-black text-[#D11217] uppercase tracking-widest mb-1">Orion Briefing</p>
              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                "Arnav, this quiz is designed to test your core conceptual understanding. Treat this as a real board environment. Focus, eliminate distractions, and conquer."
              </p>
            </div>
          </div>
        </div>

        {/* Quiz Container */}
        <div className="p-4 md:p-8 h-[700px] relative">
          {isIframeLoading && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-white dark:bg-slate-900 z-10">
              <div className="w-16 h-16 border-4 border-[#D11217] border-t-transparent rounded-full animate-spin mb-4"></div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Initialising Neural Link to Gemini Quiz...</p>
            </div>
          )}
          
          <div className="w-full h-full rounded-3xl overflow-hidden border border-slate-100 dark:border-slate-800 shadow-inner bg-slate-50 dark:bg-slate-950">
            <iframe 
              src={quizUrl}
              className="w-full h-full border-none"
              onLoad={() => setIsIframeLoading(false)}
              title="Board Exam Mock Test"
              allow="clipboard-write"
            />
          </div>
        </div>

        {/* Footer info */}
        <div className="p-6 md:p-8 border-t border-slate-100 dark:border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
             <i className="fa-solid fa-circle-info text-indigo-500"></i>
             <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest leading-relaxed">
               Note: This quiz is powered by Gemini. Ensure you are signed into your Google account for the best experience.
             </p>
          </div>
          <button 
            onClick={() => window.open(quizUrl, '_blank')}
            className="flex items-center gap-2 px-6 py-3 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-[#D11217] hover:text-white transition-all shadow-sm"
          >
            <i className="fa-solid fa-up-right-from-square"></i>
            Open Full Screen
          </button>
        </div>
      </div>
    </div>
  );
};

export default TestSeries;
