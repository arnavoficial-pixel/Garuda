
import React, { useRef, useMemo } from 'react';
import Logo from './Logo';
import { UserStats, Badge } from '../types';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  userStats?: UserStats;
  availableBadges?: Badge[];
}

const getRank = (pts: number) => {
  if (pts >= 5000) return { name: 'Vanguard', color: 'text-rose-600' };
  if (pts >= 2500) return { name: 'Grandmaster', color: 'text-purple-600' };
  if (pts >= 1000) return { name: 'Elite', color: 'text-indigo-600' };
  if (pts >= 500) return { name: 'Scholar', color: 'text-emerald-600' };
  return { name: 'Aspirant', color: 'text-slate-500' };
};

const Sidebar: React.FC<SidebarProps> = ({ 
  activeTab, 
  setActiveTab, 
  isOpen, 
  setIsOpen,
  userStats = { points: 0, badges: [], streak: 0 },
  availableBadges = []
}) => {
  const audioCtxRef = useRef<AudioContext | null>(null);

  const playFuturisticSound = () => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') ctx.resume();
      const now = ctx.currentTime;

      // Layer 1: The "Click"
      const clickOsc = ctx.createOscillator();
      const clickGain = ctx.createGain();
      clickOsc.type = 'sine';
      clickOsc.frequency.setValueAtTime(3000, now);
      clickOsc.frequency.exponentialRampToValueAtTime(1500, now + 0.02);
      clickGain.gain.setValueAtTime(0.15, now);
      clickGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.02);
      clickOsc.connect(clickGain);
      clickGain.connect(ctx.destination);
      clickOsc.start(now);
      clickOsc.stop(now + 0.02);
    } catch (e) { console.warn(e); }
  };

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'fa-house-chimney' },
    { id: 'orion', label: 'Orion AI', icon: 'fa-brain-circuit' },
    { id: 'pomodoro', label: 'Focus Timer', icon: 'fa-stopwatch' },
    { id: 'powernap', label: 'Sanctuary', icon: 'fa-moon' },
    { id: 'test', label: 'Test Series', icon: 'fa-file-pen' },
    { id: 'calculator', label: 'Calculator', icon: 'fa-calculator' },
  ];

  const handleNavClick = (id: string) => {
    playFuturisticSound();
    setActiveTab(id);
    if (window.innerWidth < 1024) setIsOpen(false);
  };

  const unlockedBadgeDetails = availableBadges.filter(b => userStats.badges.includes(b.id));
  const currentRank = useMemo(() => getRank(userStats.points), [userStats.points]);

  return (
    <>
      {isOpen && <div className="fixed inset-0 bg-black/50 z-[60] lg:hidden backdrop-blur-sm" onClick={() => setIsOpen(false)} />}
      <aside className={`fixed top-0 left-0 h-full z-[70] bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 transition-all duration-300 ease-in-out ${isOpen ? 'w-72' : 'w-0 lg:w-20'} overflow-hidden flex flex-col`}>
        <div className="flex flex-col flex-1 py-6 px-4">
          <div className={`mb-8 flex items-center transition-all duration-300 ${isOpen ? 'justify-start' : 'justify-center'}`}>
            <Logo className={isOpen ? 'w-10 h-10' : 'w-8 h-8'} />
            {isOpen && (
              <div className="ml-3">
                <h1 className="text-lg font-black text-[#D11217] tracking-tighter leading-none uppercase">Garuda</h1>
                <span className="text-[7px] font-black text-[#FFB800] uppercase tracking-widest leading-none">Pro Engine</span>
              </div>
            )}
          </div>

          <nav className="flex-1 space-y-1.5 overflow-y-auto custom-scrollbar pr-1">
            {menuItems.map((item) => (
              <button key={item.id} onClick={() => handleNavClick(item.id)} className={`w-full flex items-center gap-4 px-3.5 py-3 rounded-xl transition-all group ${activeTab === item.id ? 'bg-[#D11217] text-white shadow-lg shadow-[#D11217]/20' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}>
                <div className="w-6 flex justify-center items-center"><i className={`fa-solid ${item.icon} text-base group-hover:scale-110 transition-transform`}></i></div>
                {isOpen && <span className="font-bold text-xs tracking-tight whitespace-nowrap uppercase">{item.label}</span>}
              </button>
            ))}

            {isOpen && (
              <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Honor & Badges</p>
                <div className="space-y-3">
                  <div className="bg-slate-50 dark:bg-slate-800/50 p-3 rounded-2xl flex items-center justify-between border border-slate-100 dark:border-slate-700">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-amber-500 flex items-center justify-center text-white text-[10px]"><i className="fa-solid fa-star"></i></div>
                      <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Score</span>
                    </div>
                    <span className="text-sm font-black text-slate-800 dark:text-white">{userStats.points} GP</span>
                  </div>
                  
                  <div className="grid grid-cols-4 gap-2">
                    {unlockedBadgeDetails.map(badge => (
                      <div key={badge.id} title={badge.name} className={`w-10 h-10 rounded-xl ${badge.color} text-white flex items-center justify-center shadow-lg animate-pop`}>
                        <i className={`fa-solid ${badge.icon} text-xs`}></i>
                      </div>
                    ))}
                    {userStats.badges.length === 0 && (
                      <div className="col-span-4 py-4 text-center text-slate-400">
                        <i className="fa-solid fa-lock text-xs opacity-30 mb-1"></i>
                        <p className="text-[8px] font-bold uppercase tracking-widest">Mark chapters for badges</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </nav>

          <div className={`mt-auto pt-6 border-t border-slate-100 dark:border-slate-800 flex items-center transition-all ${isOpen ? 'justify-start' : 'justify-center'}`}>
             <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#D11217] to-[#FFB800] flex items-center justify-center text-white font-black text-[10px]">AS</div>
             {isOpen && (
               <div className="ml-2.5 overflow-hidden">
                 <p className="text-xs font-black text-slate-900 dark:text-white truncate uppercase tracking-tighter">Arnav Singh</p>
                 <p className={`text-[8px] font-bold uppercase tracking-widest leading-none ${currentRank.color}`}>{currentRank.name} Rank</p>
               </div>
             )}
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
