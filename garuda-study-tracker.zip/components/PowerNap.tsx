
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from '@google/genai';

const NAP_DURATIONS = [15, 20, 30, 45, 60];
const FIXED_THEMES = [
  { id: 'forest', name: 'Mystic Forest', icon: 'fa-tree', prompt: 'Cinematic drone shot of a misty pine forest at sunrise, high quality, realistic nature, 4k, peaceful atmosphere' },
  { id: 'ocean', name: 'Calm Ocean', icon: 'fa-water', prompt: 'Beautiful aerial view of turquoise ocean waves gently rolling onto a white sand beach, high quality, realistic nature, 4k' },
  { id: 'mountain', name: 'Snowy Peaks', icon: 'fa-mountain', prompt: 'Cinematic view of snow-capped mountains under a clear blue sky, soft clouds moving by, high quality, realistic nature, 4k' },
];

interface PowerNapProps {
  onFocusStateChange?: (isActive: boolean) => void;
}

const PowerNap: React.FC<PowerNapProps> = ({ onFocusStateChange }) => {
  const [duration, setDuration] = useState(20);
  const [mode, setMode] = useState<'nap' | 'focus'>('focus');
  const [selectedThemeId, setSelectedThemeId] = useState('orion');
  const [status, setStatus] = useState<'idle' | 'preparing' | 'generating' | 'active'>('idle');
  const [timeLeft, setTimeLeft] = useState(0);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [loadingMessage, setLoadingMessage] = useState('');
  const [progress, setProgress] = useState(0);
  const [mantra, setMantra] = useState('');

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const loadingMessages = [
    "Orion is manifesting your sanctuary...",
    "Brewing calm vibes with Garuda Intelligence...",
    "Synthesizing the neural landscape...",
    "Preparing your deep-work atmosphere...",
    "Calibrating focus frequencies for Batch 2026..."
  ];

  useEffect(() => {
    if (status === 'generating') {
      const msgInterval = setInterval(() => {
        setLoadingMessage(loadingMessages[Math.floor(Math.random() * loadingMessages.length)]);
      }, 4000);
      setLoadingMessage(loadingMessages[0]);
      return () => clearInterval(msgInterval);
    }
  }, [status]);

  const checkApiKey = async () => {
    // @ts-ignore
    const hasKey = await window.aistudio.hasSelectedApiKey();
    if (!hasKey) {
      // @ts-ignore
      await window.aistudio.openSelectKey();
    }
    return true;
  };

  const generateAIPrompt = async (ai: any) => {
    const hour = new Date().getHours();
    const timeOfDay = hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening';
    const focusGoal = mode === 'focus' ? 'deep concentration' : 'restful recharge';
    
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Generate a single, cinematic, highly detailed video prompt for a nature scene that aids ${focusGoal} during the ${timeOfDay}. Focus on elements like slow moving clouds, soft light, and natural textures. Keep it under 180 characters. Output only the prompt text.`,
      });
      return response.text.trim();
    } catch (e) {
      return FIXED_THEMES[0].prompt;
    }
  };

  const startSession = async () => {
    setStatus('preparing');
    try {
      await checkApiKey();
      setStatus('generating');
      setProgress(5);

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // Get Mantra
      const mantraRes = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Give a 5-word powerful motivational mantra for a student named Arnav Singh who is starting a ${mode === 'focus' ? 'study session' : 'power nap'}.`,
      });
      setMantra(mantraRes.text.trim());

      let finalPrompt = "";
      if (selectedThemeId === 'orion') {
        finalPrompt = await generateAIPrompt(ai);
      } else {
        finalPrompt = FIXED_THEMES.find(t => t.id === selectedThemeId)?.prompt || FIXED_THEMES[0].prompt;
      }

      setProgress(20);

      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: finalPrompt,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: '16:9'
        }
      });

      let pollCount = 0;
      while (!operation.done) {
        pollCount++;
        setProgress(Math.min(95, 20 + pollCount * 4));
        await new Promise(resolve => setTimeout(resolve, 8000));
        operation = await ai.operations.getVideosOperation({ operation: operation });
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        if (!response.ok) throw new Error("Video fetch failed");
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        setVideoUrl(url);
        setTimeLeft(duration * 60);
        setStatus('active');
        if (onFocusStateChange) onFocusStateChange(true);
      }
    } catch (error: any) {
      console.error(error);
      setStatus('idle');
      alert("Circuit disruption. Ensure your Paid API Key is active in the selection dialog.");
    }
  };

  useEffect(() => {
    if (status === 'active' && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && status === 'active') {
      setStatus('idle');
      if (onFocusStateChange) onFocusStateChange(false);
      if (timerRef.current) clearInterval(timerRef.current);
      // Play a subtle chime for nap mode
      if (mode === 'nap') {
        const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
        audio.play().catch(() => {});
      }
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [status, timeLeft, mode]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const cancelSession = () => {
    setStatus('idle');
    if (onFocusStateChange) onFocusStateChange(false);
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    setVideoUrl(null);
    if (timerRef.current) clearInterval(timerRef.current);
  };

  if (status === 'active' && videoUrl) {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black animate-in fade-in duration-1000">
        <video src={videoUrl} autoPlay loop muted className="absolute inset-0 w-full h-full object-cover opacity-50 transition-opacity duration-1000" />
        <div className="relative z-10 text-center px-6">
          <div className="mb-6 inline-flex items-center gap-2 px-4 py-1.5 bg-white/10 backdrop-blur-xl border border-white/20 rounded-full">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">{mode === 'focus' ? 'Deep Focus Engine' : 'Restoration Protocol'}</span>
          </div>
          
          <div className="text-[10vw] font-black text-white tabular-nums tracking-tighter drop-shadow-[0_10px_30px_rgba(0,0,0,0.5)] leading-none">
            {formatTime(timeLeft)}
          </div>
          
          <div className="mt-8 space-y-2">
            <p className="text-emerald-400 text-lg font-black italic tracking-tight">"{mantra}"</p>
            <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest">Orion Sanctuary Vision Active</p>
          </div>

          <button 
            onClick={cancelSession}
            className="mt-16 px-10 py-4 bg-white/5 hover:bg-white/10 border border-white/20 text-white rounded-2xl text-[10px] font-black uppercase tracking-[0.3em] transition-all backdrop-blur-md group"
          >
            <span className="group-hover:text-rose-500 transition-colors">Terminate Session</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto py-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[3rem] overflow-hidden shadow-2xl transition-all">
        {/* Banner */}
        <div className="bg-gradient-to-br from-slate-900 to-black p-10 md:p-14 text-white text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-20">
             <i className="fa-solid fa-moon text-[18rem] absolute -bottom-24 -right-24 rotate-12"></i>
             <i className="fa-solid fa-brain-circuit text-[12rem] absolute -top-10 -left-10 opacity-50"></i>
          </div>
          <div className="relative z-10">
            <div className="flex justify-center mb-6">
              <div className="flex p-1 bg-white/10 backdrop-blur-md rounded-2xl border border-white/10">
                <button 
                  onClick={() => setMode('focus')} 
                  className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${mode === 'focus' ? 'bg-emerald-500 text-white shadow-lg' : 'text-white/60 hover:text-white'}`}
                >
                  Focus Mode
                </button>
                <button 
                  onClick={() => setMode('nap')} 
                  className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${mode === 'nap' ? 'bg-amber-500 text-white shadow-lg' : 'text-white/60 hover:text-white'}`}
                >
                  Power Nap
                </button>
              </div>
            </div>
            <h2 className="text-4xl md:text-6xl font-black tracking-tighter uppercase mb-2">Sanctuary</h2>
            <p className="text-slate-400 font-bold text-xs uppercase tracking-[0.4em]">Biological & Cognitive Optimization</p>
          </div>
        </div>

        <div className="p-8 md:p-12">
          {status === 'generating' ? (
            <div className="flex flex-col items-center py-16 text-center">
              <div className="w-28 h-28 rounded-[2.5rem] bg-slate-50 dark:bg-slate-800/50 flex items-center justify-center mb-8 relative border border-slate-100 dark:border-slate-700">
                 <i className="fa-solid fa-sparkles text-4xl text-[#D11217] animate-pulse"></i>
                 <div className="absolute inset-0 border-4 border-[#D11217] border-t-transparent rounded-[2.5rem] animate-spin"></div>
              </div>
              <h3 className="text-2xl font-black text-slate-800 dark:text-white uppercase tracking-tight mb-3">{loadingMessage}</h3>
              <div className="w-full max-w-sm h-3 bg-slate-100 dark:bg-slate-800 rounded-full mt-8 overflow-hidden shadow-inner">
                 <div className="h-full bg-gradient-to-r from-[#D11217] via-[#FFB800] to-emerald-500 transition-all duration-1000" style={{ width: `${progress}%` }}></div>
              </div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mt-6">Veo 3.1 Cinematic Engine Engaged</p>
            </div>
          ) : (
            <div className="space-y-12">
              {/* Duration */}
              <div>
                <label className="text-[11px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-5 block">Temporal Setting</label>
                <div className="grid grid-cols-5 gap-3">
                  {NAP_DURATIONS.map(dur => (
                    <button
                      key={dur}
                      onClick={() => setDuration(dur)}
                      className={`py-5 rounded-3xl font-black text-xl transition-all border ${
                        duration === dur 
                          ? 'bg-slate-900 text-white border-slate-900 shadow-xl scale-105' 
                          : 'bg-white dark:bg-slate-800 text-slate-500 border-slate-100 dark:border-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {dur}
                    </button>
                  ))}
                </div>
              </div>

              {/* Theme */}
              <div>
                <label className="text-[11px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-5 block">Visual Intelligence Theme</label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <button
                    onClick={() => setSelectedThemeId('orion')}
                    className={`p-6 rounded-3xl border-2 flex flex-col items-center gap-3 transition-all relative overflow-hidden group ${
                      selectedThemeId === 'orion' 
                        ? 'border-[#D11217] bg-[#D11217]/5 shadow-inner' 
                        : 'border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300'
                    }`}
                  >
                    <div className="absolute top-2 right-2 flex gap-1">
                       <span className="w-1.5 h-1.5 bg-[#D11217] rounded-full animate-ping"></span>
                    </div>
                    <i className={`fa-solid fa-brain-circuit text-3xl ${selectedThemeId === 'orion' ? 'text-[#D11217]' : 'text-slate-400'}`}></i>
                    <span className={`text-[10px] font-black uppercase tracking-widest text-center ${selectedThemeId === 'orion' ? 'text-[#D11217]' : 'text-slate-500'}`}>Orion<br/>Personalized</span>
                  </button>
                  
                  {FIXED_THEMES.map(theme => (
                    <button
                      key={theme.id}
                      onClick={() => setSelectedThemeId(theme.id)}
                      className={`p-6 rounded-3xl border-2 flex flex-col items-center gap-3 transition-all ${
                        selectedThemeId === theme.id 
                          ? 'border-indigo-500 bg-indigo-50 shadow-inner' 
                          : 'border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900'
                      }`}
                    >
                      <i className={`fa-solid ${theme.icon} text-3xl ${selectedThemeId === theme.id ? 'text-indigo-600' : 'text-slate-400'}`}></i>
                      <span className={`text-[10px] font-black uppercase tracking-widest ${selectedThemeId === theme.id ? 'text-indigo-600' : 'text-slate-500'}`}>{theme.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-6">
                 <button 
                   onClick={startSession}
                   className="group relative w-full py-8 bg-[#D11217] text-white rounded-[2rem] font-black text-2xl uppercase tracking-[0.3em] shadow-2xl shadow-[#D11217]/30 hover:scale-[1.02] active:scale-95 transition-all overflow-hidden"
                 >
                   <span className="relative z-10 flex items-center justify-center gap-4">
                     {mode === 'focus' ? 'Engage Focus Engine' : 'Initiate Recovery'}
                     <i className="fa-solid fa-chevron-right text-lg group-hover:translate-x-2 transition-transform"></i>
                   </span>
                   <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent w-full -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
                 </button>
                 
                 <div className="flex flex-col md:flex-row items-center justify-center gap-4 mt-8 opacity-60">
                    <div className="flex items-center gap-2">
                       <i className="fa-solid fa-shield-check text-[#FFB800]"></i>
                       <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Guaranteed Deep Focus</span>
                    </div>
                    <span className="hidden md:block w-1 h-1 bg-slate-300 rounded-full"></span>
                    <div className="flex items-center gap-2">
                       <i className="fa-solid fa-sparkles text-[#D11217]"></i>
                       <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">AI Vision Powered</span>
                    </div>
                 </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PowerNap;
