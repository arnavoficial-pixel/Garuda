
import React from 'react';

const Logo: React.FC<{ className?: string, hideText?: boolean, tagline?: string, compact?: boolean }> = ({ 
  className = "w-12 h-12", 
  hideText = true,
  tagline = "TAGLINE GOES HERE",
  compact = false
}) => {
  return (
    <div className={`flex flex-col items-center justify-center ${className} transition-all duration-300`}>
      <svg viewBox="0 0 600 600" className="w-full h-auto drop-shadow-2xl" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <filter id="logoShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur in="SourceAlpha" stdDeviation="8" />
            <feOffset dx="0" dy="6" result="offsetblur" />
            <feComponentTransfer>
              <feFuncA type="linear" slope="0.4" />
            </feComponentTransfer>
            <feMerge>
              <feMergeNode />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          
          <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFD700" />
            <stop offset="100%" stopColor="#FFB800" />
          </linearGradient>

          <linearGradient id="redGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#E61920" />
            <stop offset="100%" stopColor="#D11217" />
          </linearGradient>
        </defs>
        
        <g transform="translate(50, 50)" filter="url(#logoShadow)">
          {/* Main Eagle Head Structure - Red */}
          <path 
            d="M 100,300 
               C 100,150 250,80 400,120 
               L 430,150 
               C 400,170 350,180 320,220 
               C 380,220 450,250 480,320 
               L 430,350 
               C 350,320 250,350 150,480 
               L 120,450 
               C 180,380 150,330 100,300 Z" 
            fill="url(#redGradient)" 
          />

          {/* Sharp Beak - Gold */}
          <path 
            d="M 430,150 
               C 550,180 580,350 480,450 
               C 490,400 500,350 480,320 
               L 430,150 Z" 
            fill="url(#goldGradient)" 
          />
          
          {/* Beak Separation Line */}
          <path 
            d="M 470,260 C 510,270 540,290 555,320" 
            fill="none" 
            stroke="#8a0c10" 
            strokeWidth="4" 
            strokeLinecap="round" 
            opacity="0.3"
          />

          {/* Piercing Eye - Gold/Yellow */}
          <g transform="translate(320, 190)">
            {/* Eye socket/brow */}
            <path d="M -40,-10 Q 0,-30 40,0" fill="none" stroke="#222" strokeWidth="6" strokeLinecap="round" />
            {/* The Eye */}
            <path d="M -25,0 Q 0,-15 25,0 Q 0,10 -25,0" fill="#fff" />
            <circle cx="5" cy="-2" r="8" fill="#FFB800" />
            <circle cx="7" cy="-3" r="3" fill="#000" />
            <circle cx="9" cy="-5" r="1.5" fill="#fff" opacity="0.8" />
          </g>

          {/* Neck Feather Details - Red Tones */}
          <path d="M 150,420 L 180,400 L 170,450 Z" fill="#8a0c10" opacity="0.6" />
          <path d="M 110,380 L 140,360 L 130,410 Z" fill="#8a0c10" opacity="0.6" />
        </g>
      </svg>
      
      {!hideText && (
        <div className={`text-center ${compact ? 'mt-1' : 'mt-2'}`}>
          <h1 className={`${compact ? 'text-2xl' : 'text-5xl md:text-6xl'} text-[#D11217] font-black tracking-tighter uppercase leading-none`}>
            Garuda
          </h1>
          <p className={`${compact ? 'text-[8px]' : 'text-xs md:text-sm'} text-[#FFB800] font-bold uppercase tracking-[0.4em] mt-1`}>
            {tagline}
          </p>
        </div>
      )}
    </div>
  );
};

export default Logo;
