
import React from 'react';
import { Subject, Chapter } from '../types';

interface ExamScheduleProps {
  subjects: Subject[];
  onChapterAction?: (subjectId: string, chapterId: string, action: 'questions' | 'bucket' | 'pw_lecture' | 'toggle_subtask', subtask?: string) => void;
}

const ExamSchedule: React.FC<ExamScheduleProps> = ({ subjects, onChapterAction }) => {
  
  const getChapterIcon = (name: string) => {
    const lower = name.toLowerCase();
    
    // Physics
    if (lower.includes('unit') || lower.includes('dimension')) return 'fa-ruler-combined';
    if (lower.includes('math')) return 'fa-plus-minus';
    if (lower.includes('motion')) return 'fa-person-running';
    if (lower.includes('laws')) return 'fa-hammer';
    if (lower.includes('work') || lower.includes('energy')) return 'fa-bolt';
    if (lower.includes('circular')) return 'fa-arrows-spin';
    if (lower.includes('centre of mass')) return 'fa-crosshairs';
    if (lower.includes('rotation')) return 'fa-rotate';
    if (lower.includes('gravitation')) return 'fa-globe';
    if (lower.includes('solids')) return 'fa-cube';
    if (lower.includes('fluids')) return 'fa-droplet';
    if (lower.includes('thermal') || lower.includes('thermodynamics')) return 'fa-fire-alt';
    if (lower.includes('kinetic theory')) return 'fa-wind';
    if (lower.includes('oscillation')) return 'fa-wave-square';
    if (lower.includes('waves')) return 'fa-water';
    if (lower.includes('charge') || lower.includes('current')) return 'fa-plug';
    if (lower.includes('potential') || lower.includes('capacitance')) return 'fa-battery-full';
    if (lower.includes('magnet')) return 'fa-magnet';
    if (lower.includes('induction')) return 'fa-plug-circle-bolt';
    if (lower.includes('optics')) return 'fa-eye';
    if (lower.includes('dual nature') || lower.includes('atom') || lower.includes('nuclei')) return 'fa-atom';
    if (lower.includes('semiconductor')) return 'fa-microchip';
    if (lower.includes('instrument')) return 'fa-binoculars';

    // Chemistry
    if (lower.includes('mole')) return 'fa-vials';
    if (lower.includes('atomic')) return 'fa-atom';
    if (lower.includes('states')) return 'fa-cloud';
    if (lower.includes('equilibrium')) return 'fa-arrows-rotate';
    if (lower.includes('redox')) return 'fa-vial-circle-check';
    if (lower.includes('solution')) return 'fa-flask-vial';
    if (lower.includes('electrochemistry')) return 'fa-battery-half';
    if (lower.includes('kinetic')) return 'fa-gauge-high';
    if (lower.includes('surface')) return 'fa-brush';
    if (lower.includes('organic') || lower.includes('iupac') || lower.includes('goc') || lower.includes('isomerism')) return 'fa-dna';
    if (lower.includes('hydrocarbon')) return 'fa-droplet';
    if (lower.includes('haloalkane')) return 'fa-biohazard';
    if (lower.includes('alcohol') || lower.includes('phenol')) return 'fa-wine-glass-empty';
    if (lower.includes('amine')) return 'fa-vial';
    if (lower.includes('biomolecule')) return 'fa-leaf';
    if (lower.includes('polymer')) return 'fa-link';
    if (lower.includes('periodic')) return 'fa-table-cells';
    if (lower.includes('bonding')) return 'fa-link';
    if (lower.includes('s-block') || lower.includes('p-block')) return 'fa-cubes';
    if (lower.includes('coordination')) return 'fa-diagram-project';
    if (lower.includes('metallurgy')) return 'fa-hammer';
    if (lower.includes('salt')) return 'fa-mortar-pestle';

    // Maths
    if (lower.includes('relation') || lower.includes('function')) return 'fa-code-branch';
    if (lower.includes('trigonometric')) return 'fa-mountain';
    if (lower.includes('quadratic')) return 'fa-superscript';
    if (lower.includes('sequence')) return 'fa-list-ol';
    if (lower.includes('binomial')) return 'fa-square-root-variable';
    if (lower.includes('complex')) return 'fa-i-cursor';
    if (lower.includes('permutation')) return 'fa-dice';
    if (lower.includes('line')) return 'fa-slash';
    if (lower.includes('circle')) return 'fa-circle';
    if (lower.includes('parabola') || lower.includes('ellipse') || lower.includes('hyperbola')) return 'fa-chart-area';
    if (lower.includes('limit') || lower.includes('continuity') || lower.includes('diff')) return 'fa-signature';
    if (lower.includes('integration')) return 'fa-infinity';
    if (lower.includes('integral')) return 'fa-bezier-curve';
    if (lower.includes('matrix') || lower.includes('determinant')) return 'fa-table-cells-large';
    if (lower.includes('vector')) return 'fa-location-arrow';
    if (lower.includes('3d')) return 'fa-cube';
    if (lower.includes('prob')) return 'fa-dice-six';
    if (lower.includes('stat')) return 'fa-chart-column';

    return 'fa-book';
  };

  const renderSubjectDashboard = (subject: Subject) => {
    const categories = Array.from(new Set(subject.chapters.map(c => c.category)));
    
    return (
      <div key={subject.id} className="mb-20">
        <div className="flex items-center gap-4 mb-10">
          <div className={`w-14 h-14 rounded-2xl ${subject.color} flex items-center justify-center text-white shadow-xl shadow-opacity-30`}>
            <i className={`fa-solid ${subject.icon} text-2xl`}></i>
          </div>
          <div>
            <h2 className="text-4xl font-black text-slate-900 dark:text-white uppercase tracking-tighter leading-none">{subject.name} Combat Grid</h2>
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mt-2">PW Synced • Strategic Deployment</p>
          </div>
        </div>

        <div className="space-y-16">
          {categories.map(category => {
            const chaptersInCategory = subject.chapters.filter(c => c.category === category);
            return (
              <div key={category} className="animate-in fade-in slide-in-from-bottom-6 duration-700">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-1.5 h-8 bg-[#D11217] rounded-full shadow-[0_0_15px_rgba(209,18,23,0.4)]"></div>
                  <h3 className="text-2xl font-black text-slate-800 dark:text-slate-100 tracking-tight uppercase">{category}</h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 gap-5">
                  {chaptersInCategory.map(chapter => (
                    <div 
                      key={chapter.id}
                      className="bg-[#FFFFFF] dark:bg-[#0F172A] rounded-[1.5rem] p-6 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-2xl hover:border-[#D11217]/30 transition-all group relative overflow-hidden"
                    >
                      <div className="flex items-start justify-between relative z-10">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-4">
                             <div className="w-10 h-10 rounded-full bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400 group-hover:bg-[#D11217] group-hover:text-white transition-all border border-slate-100 dark:border-slate-700">
                               <i className={`fa-solid ${getChapterIcon(chapter.name)} text-sm`}></i>
                             </div>
                             <h4 className="text-base md:text-lg font-black text-slate-800 dark:text-slate-100 group-hover:text-[#D11217] transition-colors tracking-tight uppercase leading-tight">{chapter.name}</h4>
                          </div>
                          
                          {/* PW Subtask Checklist */}
                          <div className="flex flex-wrap gap-2 mb-6">
                            <button 
                              onClick={() => onChapterAction?.(subject.id, chapter.id, 'toggle_subtask', 'lectureDone')}
                              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest border transition-all ${chapter.lectureDone ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-500' : 'bg-slate-100 dark:bg-slate-800 border-transparent text-slate-400'}`}
                            >
                              <i className={`fa-solid ${chapter.lectureDone ? 'fa-video' : 'fa-play'}`}></i>
                              Lectures
                            </button>
                            <button 
                              onClick={() => onChapterAction?.(subject.id, chapter.id, 'toggle_subtask', 'dppDone')}
                              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest border transition-all ${chapter.dppDone ? 'bg-amber-500/10 border-amber-500/30 text-amber-500' : 'bg-slate-100 dark:bg-slate-800 border-transparent text-slate-400'}`}
                            >
                              <i className={`fa-solid ${chapter.dppDone ? 'fa-file-signature' : 'fa-pen-clip'}`}></i>
                              DPP
                            </button>
                            <button 
                              onClick={() => onChapterAction?.(subject.id, chapter.id, 'toggle_subtask', 'moduleDone')}
                              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest border transition-all ${chapter.moduleDone ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-500' : 'bg-slate-100 dark:bg-slate-800 border-transparent text-slate-400'}`}
                            >
                              <i className={`fa-solid ${chapter.moduleDone ? 'fa-book-open' : 'fa-book'}`}></i>
                              Module
                            </button>
                          </div>

                          <div className="flex gap-2">
                             <button 
                               onClick={() => onChapterAction?.(subject.id, chapter.id, 'pw_lecture')}
                               className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-600/20"
                             >
                               <i className="fa-solid fa-up-right-from-square mr-2"></i>
                               Open PW App
                             </button>
                             <button 
                               onClick={() => onChapterAction?.(subject.id, chapter.id, 'questions')}
                               className="px-4 py-2 bg-rose-500/10 text-[#D11217] dark:text-rose-400 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-[#D11217] hover:text-white transition-all border border-[#D11217]/20"
                             >
                               AI Prep
                             </button>
                          </div>
                        </div>

                        <div className="flex flex-col items-center gap-3">
                          {chapter.isCompleted ? (
                            <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-lg shadow-emerald-500/30 animate-checkmark-bounce">
                              <i className="fa-solid fa-check-double text-xl"></i>
                            </div>
                          ) : (
                            <button 
                              onClick={() => onChapterAction?.(subject.id, chapter.id, 'bucket')}
                              className="w-12 h-12 rounded-2xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400 hover:bg-[#D11217] hover:text-white transition-all border border-slate-100 dark:border-slate-700"
                            >
                              <i className="fa-solid fa-chevron-right text-sm"></i>
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Tactical Progress Indicator */}
                      <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-slate-100 dark:bg-slate-800">
                        <div 
                          className={`h-full transition-all duration-1000 cubic-bezier(0.34, 1.56, 0.64, 1) ${
                            chapter.isCompleted ? 'bg-emerald-500 w-full' : 'bg-indigo-500 w-[10%]'
                          }`}
                        >
                           <div className="absolute inset-0 bg-white/20 animate-[shimmer_2s_infinite]"></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="w-full max-w-6xl mx-auto mt-32 px-4 md:px-0">
      <div className="flex flex-col items-center text-center mb-24">
         <div className="inline-flex items-center gap-3 px-8 py-3 bg-black dark:bg-[#0F172A] rounded-full border border-slate-800 mb-6 shadow-[0_20px_40px_rgba(0,0,0,0.3)] group cursor-default">
            <PWIcon />
            <span className="text-[11px] font-black text-white uppercase tracking-[0.5em] group-hover:text-indigo-500 transition-colors">Physics Wallah Ecosystem Sync</span>
         </div>
         <h1 className="text-5xl md:text-8xl font-black text-slate-900 dark:text-white uppercase tracking-tighter leading-none">Your PW Modules</h1>
         <p className="text-slate-500 font-bold text-xs uppercase tracking-[0.3em] mt-4">Automated Linkage • Real-time Task Master</p>
      </div>
      
      {subjects.map(renderSubjectDashboard)}
    </div>
  );
};

const PWIcon = () => (
  <div className="w-5 h-5 rounded-full bg-white flex items-center justify-center font-black text-[10px] text-black">PW</div>
);

export default ExamSchedule;
