
import React, { useState, useEffect, useRef } from 'react';
import { ExamCountdown } from '../types';

const CountdownTimer: React.FC = () => {
  // Target date: 1st April 2026 (JEE Mains Session 2)
  const targetDate = new Date('2026-04-01T09:00:00').getTime();
  
  const [timeLeft, setTimeLeft] = useState<ExamCountdown>({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  const [isExamStarted, setIsExamStarted] = useState(false);
  const [isSoundEnabled, setIsSoundEnabled] = useState(false);
  
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Function to play a sharp "tick" sound using Web Audio API
  const playTick = () => {
    if (!isSoundEnabled) return;
    
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      
      const ctx = audioCtxRef.current;
      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();

      oscillator.type = 'sine';
      // High frequency for a sharp "tick"
      oscillator.frequency.setValueAtTime(1200, ctx.currentTime);
      
      gainNode.gain.setValueAtTime(0.05, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.00001, ctx.currentTime + 0.03);

      oscillator.connect(gainNode);
      gainNode.connect(ctx.destination);

      oscillator.start();
      oscillator.stop(ctx.currentTime + 0.03);
    } catch (e) {
      console.error("Audio playback failed", e);
    }
  };

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference <= 0) {
        setIsExamStarted(true);
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      } else {
        const newTime = {
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000),
        };
        
        // Only play tick if seconds actually changed
        setTimeLeft(prev => {
          if (prev.seconds !== newTime.seconds) {
            playTick();
          }
          return newTime;
        });
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [targetDate, isSoundEnabled]);

  const TimeUnit = ({ value, label }: { value: number, label: string }) => (
    <div className="flex flex-col items-center px-4 py-2 bg-white/10 rounded-xl backdrop-blur-sm border border-white/20 min-w-[75px] md:min-w-[85px] shadow-inner transition-all hover:bg-white/20">
      <span className="text-3xl md:text-4xl font-black text-white tabular-nums">{value.toString().padStart(2, '0')}</span>
      <span className="text-[10px] uppercase tracking-widest text-indigo-100 font-bold">{label}</span>
    </div>
  );

  return (
    <div className="w-full max-w-2xl mx-auto mb-10">
      <div className="bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-800 rounded-3xl p-6 md:p-10 shadow-2xl relative overflow-hidden border border-white/10">
        {/* Decorative elements */}
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-white/5 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-indigo-400/10 rounded-full blur-3xl"></div>
        
        <div className="relative z-10 flex flex-col items-center">
          {/* Header & Sound Toggle */}
          <div className="w-full flex justify-between items-center mb-6">
            <div className="bg-white/20 px-4 py-1.5 rounded-full backdrop-blur-md border border-white/20">
              <h2 className="text-white font-bold text-[10px] md:text-xs uppercase tracking-[0.2em] flex items-center gap-2">
                <i className="fa-solid fa-calendar-check"></i>
                Target: JEE Mains Session 2 (1st April 2026)
              </h2>
            </div>
            
            <button 
              onClick={() => setIsSoundEnabled(!isSoundEnabled)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-full backdrop-blur-md border transition-all ${
                isSoundEnabled 
                ? 'bg-indigo-400/30 border-indigo-300 text-white' 
                : 'bg-white/10 border-white/10 text-white/50'
              }`}
            >
              <i className={`fa-solid ${isSoundEnabled ? 'fa-volume-high animate-pulse' : 'fa-volume-xmark'}`}></i>
              <span className="text-[10px] font-bold uppercase tracking-wider">{isSoundEnabled ? 'Tick On' : 'Tick Off'}</span>
            </button>
          </div>
          
          {isExamStarted ? (
            <div className="text-center py-4">
              <h3 className="text-3xl font-black text-white mb-2">JEE Mains Session 2 Started!</h3>
              <p className="text-indigo-100 font-medium">Wishing you ultimate success, Arnav Singh!</p>
            </div>
          ) : (
            <div className="flex flex-col md:flex-row items-center gap-6">
              {/* Rotating Sand Clock with Pulse Effect */}
              <div className="flex items-center justify-center relative">
                {/* Outer Glow Pulse - Key triggers animation on every second change */}
                <div key={`pulse-${timeLeft.seconds}`} className="absolute inset-0 bg-white/20 rounded-full blur-xl animate-pop opacity-40"></div>
                
                <div 
                  key={`icon-${timeLeft.seconds}`}
                  className="w-16 h-16 md:w-20 md:h-20 bg-white/10 rounded-full flex items-center justify-center border border-white/20 shadow-lg transition-transform duration-700 ease-in-out animate-pop"
                  style={{ transform: `rotate(${timeLeft.seconds * 6}deg)` }}
                >
                  <i className="fa-solid fa-hourglass-half text-white text-3xl md:text-4xl"></i>
                </div>
              </div>

              <div className="flex flex-wrap justify-center gap-3 md:gap-4">
                <TimeUnit value={timeLeft.days} label="Days" />
                <TimeUnit value={timeLeft.hours} label="Hours" />
                <TimeUnit value={timeLeft.minutes} label="Mins" />
                <TimeUnit value={timeLeft.seconds} label="Secs" />
              </div>
            </div>
          )}
          
          <div className="mt-10 flex items-center gap-3 text-indigo-100/60 text-[10px] uppercase tracking-[0.3em] font-black">
            <span className="h-[1px] w-6 bg-white/20"></span>
            Mission: IIT 2026
            <span className="h-[1px] w-6 bg-white/20"></span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CountdownTimer;
