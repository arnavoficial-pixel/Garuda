
import React, { useState } from 'react';

const ScientificCalculator: React.FC = () => {
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');

  const handleInput = (val: string) => {
    if (display === '0' || display === 'Error') {
      setDisplay(val);
    } else {
      setDisplay(display + val);
    }
  };

  const clear = () => {
    setDisplay('0');
    setEquation('');
  };

  const backspace = () => {
    setDisplay(display.length > 1 ? display.slice(0, -1) : '0');
  };

  const calculate = () => {
    try {
      // Basic sanitization for eval - in a real app use a math parser library
      let finalExpr = display
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/π/g, 'Math.PI')
        .replace(/e/g, 'Math.E')
        .replace(/sin\(/g, 'Math.sin(')
        .replace(/cos\(/g, 'Math.cos(')
        .replace(/tan\(/g, 'Math.tan(')
        .replace(/log\(/g, 'Math.log10(')
        .replace(/ln\(/g, 'Math.log(')
        .replace(/√\(/g, 'Math.sqrt(')
        .replace(/\^/g, '**');

      const result = eval(finalExpr);
      setEquation(display + ' =');
      setDisplay(Number.isFinite(result) ? result.toString() : 'Error');
    } catch (e) {
      setDisplay('Error');
    }
  };

  const CalcButton = ({ label, onClick, className = "", scientific = false }: any) => (
    <button
      onClick={onClick}
      className={`p-3 md:p-4 rounded-xl font-bold text-sm md:text-base transition-all active:scale-95 shadow-sm border ${
        scientific 
          ? 'bg-slate-800/40 border-slate-700 text-indigo-300 hover:bg-slate-700/60' 
          : className || 'bg-white dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800/60'
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="w-full max-w-md mx-auto animate-in zoom-in-95 duration-500">
      <div className="bg-slate-900/80 backdrop-blur-2xl rounded-[2.5rem] p-6 md:p-8 border border-slate-800 shadow-2xl relative overflow-hidden">
        {/* Galaxy themed background inside calculator */}
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <div className="absolute top-10 left-10 w-32 h-32 bg-indigo-500/30 rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-32 h-32 bg-[#D11217]/20 rounded-full blur-3xl"></div>
        </div>

        <div className="relative z-10">
          {/* Display */}
          <div className="bg-black/40 rounded-2xl p-6 mb-6 text-right border border-slate-800/50 shadow-inner">
            <div className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest h-4 overflow-hidden mb-1">
              {equation}
            </div>
            <div className="text-3xl md:text-4xl font-black text-white truncate tabular-nums">
              {display}
            </div>
          </div>

          {/* Pad */}
          <div className="grid grid-cols-4 md:grid-cols-5 gap-2 md:gap-3">
            {/* Scientific Row 1 */}
            <CalcButton label="sin" onClick={() => handleInput('sin(')} scientific />
            <CalcButton label="cos" onClick={() => handleInput('cos(')} scientific />
            <CalcButton label="tan" onClick={() => handleInput('tan(')} scientific />
            <CalcButton label="log" onClick={() => handleInput('log(')} scientific className="hidden md:flex" />
            <CalcButton label="ln" onClick={() => handleInput('ln(')} scientific className="hidden md:flex" />

            {/* Scientific Row 2 */}
            <CalcButton label="√" onClick={() => handleInput('√(')} scientific />
            <CalcButton label="π" onClick={() => handleInput('π')} scientific />
            <CalcButton label="e" onClick={() => handleInput('e')} scientific />
            <CalcButton label="(" onClick={() => handleInput('(')} scientific />
            <CalcButton label=")" onClick={() => handleInput(')')} scientific />

            {/* Basic Ops Row 1 */}
            <CalcButton label="C" onClick={clear} className="bg-rose-500/10 border-rose-500/20 text-rose-500 hover:bg-rose-500/20" />
            <CalcButton label="⌫" onClick={backspace} />
            <CalcButton label="^" onClick={() => handleInput('^')} />
            <CalcButton label="÷" onClick={() => handleInput('÷')} className="text-[#FFB800]" />
            <CalcButton label="inv" onClick={() => handleInput('1/(')} scientific className="hidden md:flex" />

            {/* Numbers & Basic Ops */}
            {[7, 8, 9].map(n => <CalcButton key={n} label={n.toString()} onClick={() => handleInput(n.toString())} />)}
            <CalcButton label="×" onClick={() => handleInput('×')} className="text-[#FFB800]" />
            <CalcButton label="x²" onClick={() => handleInput('^2')} scientific className="hidden md:flex" />

            {[4, 5, 6].map(n => <CalcButton key={n} label={n.toString()} onClick={() => handleInput(n.toString())} />)}
            <CalcButton label="-" onClick={() => handleInput('-')} className="text-[#FFB800]" />
            <CalcButton label="EXP" onClick={() => handleInput('e')} scientific className="hidden md:flex" />

            {[1, 2, 3].map(n => <CalcButton key={n} label={n.toString()} onClick={() => handleInput(n.toString())} />)}
            <CalcButton label="+" onClick={() => handleInput('+')} className="text-[#FFB800]" />
            <CalcButton label="ANS" onClick={() => {}} scientific className="hidden md:flex" />

            <CalcButton label="0" onClick={() => handleInput('0')} className="col-span-1" />
            <CalcButton label="." onClick={() => handleInput('.')} />
            <CalcButton label="=" onClick={calculate} className="col-span-2 md:col-span-3 bg-[#D11217] text-white border-transparent hover:bg-[#b00f13] shadow-lg shadow-[#D11217]/30" />
          </div>
        </div>
      </div>
      <p className="mt-4 text-center text-[10px] font-bold text-slate-500 uppercase tracking-widest opacity-60">Scientific Mode • Galaxy Engine</p>
    </div>
  );
};

export default ScientificCalculator;
