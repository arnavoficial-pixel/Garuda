
import React, { useEffect, useRef } from 'react';

interface GalaxyBackgroundProps {
  progress?: number;
  isFocusMode?: boolean;
}

const GalaxyBackground: React.FC<GalaxyBackgroundProps> = ({ progress = 0, isFocusMode = false }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;

    let animationFrameId: number;
    let w = canvas.width = window.innerWidth;
    let h = canvas.height = window.innerHeight;

    const SCIENCE_GLYPHS = ['∑', '∫', 'π', '∞', 'λ', 'Ω', '⚛', '∆', '√'];
    const STAR_COUNT = 150 + Math.floor(progress * 2); // Progress adds more stars
    const GLYPH_COUNT = 15;
    const DUST_COUNT = 40;

    class Entity {
      x: number = 0;
      y: number = 0;
      z: number = 0;
      size: number = 0;
      opacity: number = 0;
      speed: number = 0;
      type: string = '';
      content: string = '';

      constructor(w: number, h: number, type: string) {
        this.reset(w, h, type);
      }

      reset(w: number, h: number, type: string) {
        this.type = type;
        this.x = Math.random() * w;
        this.y = Math.random() * h;
        this.z = Math.random() * 2 + 1; // Depth layer
        this.opacity = Math.random();
        
        if (type === 'star') {
          this.size = Math.random() * 1.5 + 0.5;
          this.speed = (Math.random() * 0.02 + 0.005) * (isFocusMode ? 0.3 : 1);
        } else if (type === 'glyph') {
          this.size = Math.random() * 15 + 10;
          this.content = SCIENCE_GLYPHS[Math.floor(Math.random() * SCIENCE_GLYPHS.length)];
          this.speed = (Math.random() * 0.1 + 0.05) * (isFocusMode ? 0.2 : 1);
        } else {
          this.size = Math.random() * 2 + 1;
          this.speed = (Math.random() * 0.3 + 0.1) * (isFocusMode ? 0.4 : 1);
        }
      }

      update(w: number, h: number, mouseX: number, mouseY: number) {
        // Continuous movement
        this.y -= this.speed;
        
        // Parallax effect based on mouse
        const px = (mouseX - w/2) * (0.01 * this.z);
        const py = (mouseY - h/2) * (0.01 * this.z);
        
        const drawX = this.x + px;
        const drawY = this.y + py;

        if (this.y < -50) this.y = h + 50;

        return { drawX, drawY };
      }
    }

    const entities: Entity[] = [];
    const meteors: { x: number, y: number, len: number, s: number, o: number }[] = [];

    const init = () => {
      entities.length = 0;
      for (let i = 0; i < STAR_COUNT; i++) entities.push(new Entity(w, h, 'star'));
      for (let i = 0; i < DUST_COUNT; i++) entities.push(new Entity(w, h, 'dust'));
      for (let i = 0; i < GLYPH_COUNT; i++) entities.push(new Entity(w, h, 'glyph'));
    };

    const draw = () => {
      // Background Gradient Pulse
      const gradient = ctx.createRadialGradient(w/2, h/2, 0, w/2, h/2, w);
      if (isFocusMode) {
        gradient.addColorStop(0, '#020617'); // Focus Mode: Deep Dark Blue
        gradient.addColorStop(1, '#000000');
      } else {
        gradient.addColorStop(0, '#0f172a'); // Standard Mode: Navy/Slate
        gradient.addColorStop(0.5, '#020617');
        gradient.addColorStop(1, '#000000');
      }
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, w, h);

      // Interpolate mouse for smoothness
      mouseRef.current.x += (mouseRef.current.targetX - mouseRef.current.x) * 0.05;
      mouseRef.current.y += (mouseRef.current.targetY - mouseRef.current.y) * 0.05;

      // Draw Entities
      entities.forEach(e => {
        const { drawX, drawY } = e.update(w, h, mouseRef.current.x, mouseRef.current.y);
        
        if (e.type === 'star') {
          ctx.fillStyle = `rgba(255, 255, 255, ${Math.abs(Math.sin(Date.now() * 0.001 * e.z) * 0.5 + 0.5) * 0.8})`;
          ctx.beginPath();
          ctx.arc(drawX, drawY, e.size, 0, Math.PI * 2);
          ctx.fill();
        } else if (e.type === 'glyph') {
          ctx.fillStyle = `rgba(148, 163, 184, 0.08)`; // Very subtle
          ctx.font = `${e.size}px serif`;
          ctx.fillText(e.content, drawX, drawY);
        } else {
          ctx.fillStyle = `rgba(99, 102, 241, 0.15)`; // Indigo dust
          ctx.beginPath();
          ctx.arc(drawX, drawY, e.size, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      // Meteors
      if (!isFocusMode && Math.random() < 0.005) {
        meteors.push({
          x: Math.random() * w,
          y: -100,
          len: Math.random() * 100 + 50,
          s: Math.random() * 15 + 10,
          o: 1
        });
      }

      meteors.forEach((m, i) => {
        m.x -= m.s;
        m.y += m.s;
        m.o -= 0.015;
        if (m.o <= 0) {
          meteors.splice(i, 1);
        } else {
          ctx.strokeStyle = `rgba(255, 255, 255, ${m.o})`;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(m.x, m.y);
          ctx.lineTo(m.x + m.len, m.y - m.len);
          ctx.stroke();
        }
      });

      animationFrameId = requestAnimationFrame(draw);
    };

    init();
    draw();

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.targetX = e.clientX;
      mouseRef.current.targetY = e.clientY;
    };

    const handleResize = () => {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
      init();
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('resize', handleResize);
    
    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
    };
  }, [progress, isFocusMode]);

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 pointer-events-none z-0"
    />
  );
};

export default GalaxyBackground;
