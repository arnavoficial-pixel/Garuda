
import React from 'react';
import { Subject } from '../types';

interface SubjectCardProps {
  subject: Subject;
  onClick: () => void;
}

const SubjectCard: React.FC<SubjectCardProps> = ({ subject, onClick }) => {
  const completedCount = subject.chapters.filter(c => c.isCompleted).length;
  const totalCount = subject.chapters.length;
  const progress = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;

  const getProgressGradient = (p: number) => {
    if (p < 30) return 'from-rose-500 to-rose-600 shadow-rose-500/20';
    if (p < 70) return 'from-amber-400 to-amber-500 shadow-amber-500/20';
    return 'from-emerald-400 to-emerald-600 shadow-emerald-500/20';
  };

  return (
    <button
      onClick={onClick}
      className="flex flex-col text-left w-full bg-white dark:bg-slate-900 rounded-3xl shadow-sm hover:shadow-2xl hover:scale-[1.02] hover:-translate-y-1.5 transition-all duration-500 ease-out border border-slate-100 dark:border-slate-800 group overflow-hidden"
    >
      <div className={`w-full h-2 ${subject.color}`}></div>
      <div className="p-6 flex flex-col h-full w-full">
        <div className="flex justify-between items-start mb-5">
          <div className={`p-3.5 rounded-2xl ${subject.color} text-white shadow-lg shadow-opacity-20 group-hover:scale-110 transition-transform duration-500`}>
            <i className={`fa-solid ${subject.icon} text-2xl`}></i>
          </div>
          <div className="text-right">
            <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Mastery</span>
            <div className="text-xl font-black text-slate-800 dark:text-white tabular-nums">{Math.round(progress)}%</div>
          </div>
        </div>
        
        <div className="mb-5">
          <h3 className="text-2xl font-black text-slate-800 dark:text-slate-100 leading-tight tracking-tight uppercase">{subject.name}</h3>
          <p className="text-sm font-bold text-slate-500 dark:text-slate-400 tracking-wide mt-1">{subject.hindiName}</p>
        </div>

        <div className="mt-auto">
          <div className="flex justify-between text-[10px] font-black text-slate-400 dark:text-slate-500 mb-2.5 uppercase tracking-tighter">
            <span>{completedCount} / {totalCount} Chapters Done</span>
            <span className="text-indigo-500 dark:text-indigo-400">{totalCount - completedCount} Remaining</span>
          </div>
          <div className="w-full h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden shadow-inner relative border border-slate-50 dark:border-slate-800">
            <div 
              className={`h-full bg-gradient-to-r ${getProgressGradient(progress)} transition-all duration-1000 cubic-bezier(0.34, 1.56, 0.64, 1) shadow-lg relative`}
              style={{ width: `${progress}%` }}
            >
              {/* Animated Shine Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent w-full animate-[shimmer_3s_infinite] -translate-x-full"></div>
            </div>
          </div>
        </div>
      </div>
    </button>
  );
};

export default SubjectCard;
