
import React, { useState, useEffect, useRef } from 'react';

interface PomodoroTimerProps {
  onCompleteSession: (points: number) => void;
}

type TimerMode = 'work' | 'shortBreak' | 'longBreak';

const PomodoroTimer: React.FC<PomodoroTimerProps> = ({ onCompleteSession }) => {
  const [mode, setMode] = useState<TimerMode>('work');
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [sessionsCompleted, setSessionsCompleted] = useState(0);
  
  // Settings
  const [settings, setSettings] = useState({
    work: 25,
    shortBreak: 5,
    longBreak: 15,
  });
  const [showSettings, setShowSettings] = useState(false);

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const playSound = (type: 'start' | 'end' | 'tick') => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      if (type === 'start') {
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.2);
      } else if (type === 'end') {
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.3);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.5);
      } else {
        osc.frequency.setValueAtTime(1000, ctx.currentTime);
        gain.gain.setValueAtTime(0.02, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.05);
      }

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.5);
    } catch (e) { /* Audio fallback */ }
  };

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => prev - 1);
        if (timeLeft % 60 === 0) playSound('tick');
      }, 1000);
    } else if (timeLeft === 0 && isActive) {
      handleTimerComplete();
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isActive, timeLeft]);

  const handleTimerComplete = () => {
    setIsActive(false);
    playSound('end');
    
    if (mode === 'work') {
      const nextSessionCount = sessionsCompleted + 1;
      setSessionsCompleted(nextSessionCount);
      onCompleteSession(50); // Award 50 GP for a focused work session
      
      if (nextSessionCount % 4 === 0) {
        setMode('longBreak');
        setTimeLeft(settings.longBreak * 60);
      } else {
        setMode('shortBreak');
        setTimeLeft(settings.shortBreak * 60);
      }
    } else {
      setMode('work');
      setTimeLeft(settings.work * 60);
    }
  };

  const toggleTimer = () => {
    if (!isActive) playSound('start');
    setIsActive(!isActive);
  };

  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(settings[mode] * 60);
  };

  const changeMode = (newMode: TimerMode) => {
    setMode(newMode);
    setIsActive(false);
    setTimeLeft(settings[newMode] * 60);
  };

  const updateSetting = (key: keyof typeof settings, val: number) => {
    const newSettings = { ...settings, [key]: Math.max(1, val) };
    setSettings(newSettings);
    if (mode === key) {
      setTimeLeft(newSettings[key] * 60);
      setIsActive(false);
    }
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const progress = (timeLeft / (settings[mode] * 60)) * 100;
  const strokeDasharray = 2 * Math.PI * 90;
  const strokeDashoffset = strokeDasharray - (progress / 100) * strokeDasharray;

  const modeColors = {
    work: 'text-[#D11217] border-[#D11217]',
    shortBreak: 'text-emerald-500 border-emerald-500',
    longBreak: 'text-blue-500 border-blue-500',
  };

  const modeGradients = {
    work: 'from-[#D11217] to-[#8a0c10]',
    shortBreak: 'from-emerald-400 to-emerald-600',
    longBreak: 'from-blue-400 to-blue-600',
  };

  return (
    <div className="w-full max-w-2xl mx-auto py-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[3rem] overflow-hidden shadow-2xl">
        <div className={`h-2 bg-gradient-to-r ${modeGradients[mode]}`}></div>
        
        <div className="p-8 md:p-12">
          {/* Tabs */}
          <div className="flex justify-center mb-10">
            <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
              <button 
                onClick={() => changeMode('work')} 
                className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${mode === 'work' ? 'bg-[#D11217] text-white shadow-lg' : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'}`}
              >
                Work
              </button>
              <button 
                onClick={() => changeMode('shortBreak')} 
                className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${mode === 'shortBreak' ? 'bg-emerald-500 text-white shadow-lg' : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'}`}
              >
                Short Break
              </button>
              <button 
                onClick={() => changeMode('longBreak')} 
                className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${mode === 'longBreak' ? 'bg-blue-500 text-white shadow-lg' : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'}`}
              >
                Long Break
              </button>
            </div>
          </div>

          {/* Timer Circle */}
          <div className="relative flex items-center justify-center mb-12 group">
            <svg className="w-64 h-64 md:w-80 md:h-80 -rotate-90">
              <circle
                cx="50%" cy="50%" r="90"
                className="fill-none stroke-slate-100 dark:stroke-slate-800"
                strokeWidth="8"
              />
              <circle
                cx="50%" cy="50%" r="90"
                className={`fill-none transition-all duration-1000 ease-linear ${modeColors[mode].split(' ')[1]}`}
                strokeWidth="8"
                strokeLinecap="round"
                style={{ strokeDasharray, strokeDashoffset }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className={`text-6xl md:text-7xl font-black tabular-nums tracking-tighter ${modeColors[mode].split(' ')[0]}`}>
                {formatTime(timeLeft)}
              </div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] mt-2">
                {mode === 'work' ? 'Concentration' : 'Recovery'}
              </p>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-6 mb-12">
            <button 
              onClick={resetTimer}
              className="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-500 flex items-center justify-center hover:bg-slate-200 dark:hover:bg-slate-700 transition-all active:scale-90"
            >
              <i className="fa-solid fa-rotate-left text-xl"></i>
            </button>
            
            <button 
              onClick={toggleTimer}
              className={`w-24 h-24 rounded-[2.5rem] flex items-center justify-center text-white shadow-2xl transition-all hover:scale-105 active:scale-95 bg-gradient-to-br ${modeGradients[mode]}`}
            >
              <i className={`fa-solid ${isActive ? 'fa-pause' : 'fa-play'} text-3xl`}></i>
            </button>

            <button 
              onClick={() => setShowSettings(!showSettings)}
              className="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-500 flex items-center justify-center hover:bg-slate-200 dark:hover:bg-slate-700 transition-all active:scale-90"
            >
              <i className="fa-solid fa-sliders text-xl"></i>
            </button>
          </div>

          {/* Stats/Settings */}
          {showSettings ? (
            <div className="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 animate-in zoom-in-95 duration-300">
              <div className="flex items-center justify-between mb-6">
                <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Timer Intervals (Mins)</h4>
                <button onClick={() => setShowSettings(false)} className="text-[10px] font-black text-[#D11217] uppercase tracking-widest">Close</button>
              </div>
              <div className="grid grid-cols-3 gap-4">
                {(Object.keys(settings) as Array<keyof typeof settings>).map(key => (
                  <div key={key}>
                    {/* Fixed: TypeScript error where key.replace might not exist. Casting to string to ensure replace is available. */}
                    <label className="text-[8px] font-black uppercase tracking-widest text-slate-400 block mb-2">{String(key).replace(/([A-Z])/g, ' $1')}</label>
                    <input 
                      type="number" 
                      value={settings[key]} 
                      onChange={(e) => updateSetting(key, parseInt(e.target.value) || 1)}
                      className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-sm font-bold text-slate-800 dark:text-white"
                    />
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between px-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#D11217]/10 flex items-center justify-center text-[#D11217]">
                  <i className="fa-solid fa-fire-flame-curved"></i>
                </div>
                <div>
                  <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Sessions</p>
                  <p className="text-sm font-black text-slate-800 dark:text-white">#{sessionsCompleted}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Potential Rewards</p>
                <p className="text-sm font-black text-emerald-500">+50 GP / Session</p>
              </div>
            </div>
          )}
        </div>
      </div>
      <p className="text-center mt-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Garuda Focus Protocol • 2026</p>
    </div>
  );
};

export default PomodoroTimer;
