
import React from 'react';
import OrionLogo from './OrionLogo';

interface PDFViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  fileUrl: string | null;
  fileName: string | null;
}

const PDFViewerModal: React.FC<PDFViewerModalProps> = ({ isOpen, onClose, fileUrl, fileName }) => {
  if (!isOpen || !fileUrl) return null;

  const handleDownload = () => {
    if (fileUrl && fileName) {
      const link = document.createElement('a');
      link.href = fileUrl;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8 animate-in fade-in duration-300">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={onClose} />
      
      <div className="relative w-full max-w-5xl h-full bg-white dark:bg-slate-900 rounded-3xl overflow-hidden shadow-2xl flex flex-col border border-white/10">
        {/* Header */}
        <div className="flex items-center justify-between p-4 md:px-6 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <OrionLogo className="w-10 h-10" />
            <div>
              <h3 className="text-sm font-black text-slate-900 dark:text-white truncate max-w-[200px] md:max-w-md uppercase tracking-tighter">
                {fileName}
              </h3>
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Orion Intelligence • Secure Viewer</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 hover:text-[#D11217] transition-all active:scale-90"
          >
            <i className="fa-solid fa-xmark text-lg"></i>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 bg-slate-100 dark:bg-slate-950/50 p-2 md:p-4">
          <iframe 
            src={`${fileUrl}#toolbar=1&navpanes=0&scrollbar=1`} 
            className="w-full h-full rounded-2xl border-none shadow-inner"
            title="PDF Preview"
          />
        </div>

        {/* Footer */}
        <div className="p-4 flex items-center justify-center gap-4 bg-white dark:bg-slate-900">
           <button 
             onClick={handleDownload}
             className="px-6 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-white rounded-xl font-black text-[10px] uppercase tracking-[0.2em] shadow-md hover:bg-slate-200 dark:hover:bg-slate-700 transition-all flex items-center gap-2 border border-slate-200 dark:border-slate-700"
           >
             <i className="fa-solid fa-download"></i>
             Download
           </button>
           <button 
             onClick={onClose}
             className="px-8 py-2.5 bg-[#D11217] text-white rounded-xl font-black text-[10px] uppercase tracking-[0.2em] shadow-lg shadow-[#D11217]/20 hover:scale-105 active:scale-95 transition-all"
           >
             Close Viewer
           </button>
        </div>
      </div>
    </div>
  );
};

export default PDFViewerModal;
