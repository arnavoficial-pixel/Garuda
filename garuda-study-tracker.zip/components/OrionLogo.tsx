
import React from 'react';

const OrionLogo: React.FC<{ className?: string }> = ({ className = "w-12 h-12" }) => {
  return (
    <div className={`${className} relative group transition-all duration-700 select-none`}>
      <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
        <defs>
          <filter id="orionGlow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
          
          <linearGradient id="coreGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF3B41" />
            <stop offset="100%" stopColor="#D11217" />
          </linearGradient>

          <linearGradient id="goldBeam" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFD700" />
            <stop offset="100%" stopColor="#FFB800" />
          </linearGradient>

          <filter id="innerShadow">
            <feOffset dx="0" dy="2" />
            <feGaussianBlur stdDeviation="2" result="offset-blur" />
            <feComposite operator="out" in="SourceGraphic" in2="offset-blur" result="inverse" />
            <feFlood floodColor="black" floodOpacity="0.3" result="color" />
            <feComposite operator="in" in="color" in2="inverse" result="shadow" />
            <feComposite operator="over" in="shadow" in2="SourceGraphic" />
          </filter>
        </defs>
        
        {/* Outer Pulsing Aura (Invisible initially, appears on group hover) */}
        <circle cx="100" cy="100" r="85" fill="rgba(209, 18, 23, 0.03)" className="group-hover:animate-pulse" />

        {/* Outer Hexagonal Shield - Structural */}
        <path 
          d="M100 15 L175 57.5 L175 142.5 L100 185 L25 142.5 L25 57.5 Z" 
          stroke="url(#coreGradient)" 
          strokeWidth="1.5" 
          strokeOpacity="0.2"
          fill="rgba(209, 18, 23, 0.02)" 
        />

        {/* Secondary Inner Hexagon - Technical Detail */}
        <path 
          d="M100 35 L155 67 L155 133 L100 165 L45 133 L45 67 Z" 
          stroke="#FFB800" 
          strokeWidth="0.5" 
          strokeOpacity="0.3"
          strokeDasharray="10 5"
          className="animate-[spin_20s_linear_infinite]"
          style={{ transformOrigin: 'center' }}
        />

        {/* Neural Network Connections */}
        <g opacity="0.4">
          <circle cx="100" cy="35" r="3" fill="#FFB800" />
          <circle cx="155" cy="67" r="3" fill="#FFB800" />
          <circle cx="155" cy="133" r="3" fill="#FFB800" />
          <circle cx="100" cy="165" r="3" fill="#FFB800" />
          <circle cx="45" cy="133" r="3" fill="#FFB800" />
          <circle cx="45" cy="67" r="3" fill="#FFB800" />
          
          <path d="M100 35 L100 65" stroke="#FFB800" strokeWidth="1" />
          <path d="M155 67 L125 85" stroke="#FFB800" strokeWidth="1" />
          <path d="M155 133 L125 115" stroke="#FFB800" strokeWidth="1" />
          <path d="M100 165 L100 135" stroke="#FFB800" strokeWidth="1" />
          <path d="M45 133 L75 115" stroke="#FFB800" strokeWidth="1" />
          <path d="M45 67 L75 85" stroke="#FFB800" strokeWidth="1" />
        </g>

        {/* Central Intelligence Core */}
        <g filter="url(#orionGlow)">
          {/* Core Shell */}
          <circle 
            cx="100" 
            cy="100" 
            r="35" 
            fill="url(#coreGradient)" 
            className="animate-pulse"
            style={{ animationDuration: '3s' }}
          />
          
          {/* Inner Light Processor */}
          <rect 
            x="82" y="82" width="36" height="36" rx="8" 
            fill="rgba(255,255,255,0.1)" 
            stroke="white" 
            strokeWidth="2" 
            strokeOpacity="0.5"
            className="group-hover:rotate-45 transition-transform duration-700"
            style={{ transformOrigin: 'center' }}
          />

          {/* Vertical Processor Core */}
          <path 
            d="M100 88 V112 M90 100 H110" 
            stroke="white" 
            strokeWidth="3" 
            strokeLinecap="round" 
            className="group-hover:scale-110 transition-transform"
            style={{ transformOrigin: 'center' }}
          />
        </g>

        {/* Orbital Satellite Nodes */}
        <g className="animate-[spin_12s_linear_infinite]" style={{ transformOrigin: 'center' }}>
          <circle cx="100" cy="20" r="5" fill="url(#goldBeam)" filter="url(#orionGlow)" />
          <circle cx="100" cy="180" r="3" fill="url(#goldBeam)" opacity="0.5" />
        </g>
      </svg>
      
      {/* Interactive Background Glow */}
      <div className="absolute inset-0 bg-red-600/10 blur-[40px] rounded-full scale-50 opacity-0 group-hover:opacity-100 group-hover:scale-125 transition-all duration-700 pointer-events-none"></div>
    </div>
  );
};

export default OrionLogo;
