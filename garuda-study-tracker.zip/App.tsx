
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Subject, Chapter, StudyFile, UserStats, Badge } from './types';
import { INITIAL_SUBJECTS } from './constants';
import Logo from './components/Logo';
import CountdownTimer from './components/CountdownTimer';
import SubjectCard from './components/SubjectCard';
import ExamSchedule from './components/ExamSchedule';
import GalaxyBackground from './components/GalaxyBackground';
import Sidebar from './components/Sidebar';
import ScientificCalculator from './components/ScientificCalculator';
import OrionAI from './components/OrionAI';
import OrionLogo from './components/OrionLogo';
import PowerNap from './components/PowerNap';
import TestSeries from './components/TestSeries';
import PDFViewerModal from './components/PDFViewerModal';
import PomodoroTimer from './components/PomodoroTimer';
import { GoogleGenAI } from '@google/genai';
import { saveFile, getFile, deleteFile } from './utils/db';

const BADGES: Badge[] = [
  { id: 'phys_adept', name: 'Physics Adept', icon: 'fa-bolt-lightning', color: 'bg-amber-400', description: 'Complete 25% of Physics' },
  { id: 'phys_titan', name: 'Physics Titan', icon: 'fa-bolt', color: 'bg-amber-600', description: 'Complete 50% of Physics' },
  { id: 'phys_apex', name: 'Physics Apex', icon: 'fa-sun', color: 'bg-amber-700', description: 'Complete 100% of Physics' },
  { id: 'chem_adept', name: 'Chem Initiate', icon: 'fa-vial', color: 'bg-emerald-400', description: 'Complete 25% of Chemistry' },
  { id: 'chem_catalyst', name: 'Chem Catalyst', icon: 'fa-flask', color: 'bg-emerald-600', description: 'Complete 50% of Chemistry' },
  { id: 'chem_apex', name: 'Chem Alchemist', icon: 'fa-atom', color: 'bg-emerald-700', description: 'Complete 100% of Chemistry' },
  { id: 'math_adept', name: 'Math Scholar', icon: 'fa-square-root-variable', color: 'bg-blue-400', description: 'Complete 25% of Mathematics' },
  { id: 'math_wizard', name: 'Math Maverick', icon: 'fa-calculator', color: 'bg-blue-600', description: 'Complete 50% of Mathematics' },
  { id: 'math_apex', name: 'Math Architect', icon: 'fa-infinity', color: 'bg-blue-800', description: 'Complete 100% of Mathematics' },
  { id: 'garuda_vanguard', name: 'Garuda Vanguard', icon: 'fa-shield-halved', color: 'bg-rose-600', description: 'Reach 5000 Garuda Points' },
];

const getRank = (pts: number) => {
  if (pts >= 5000) return { name: 'Vanguard', color: 'text-rose-600', bg: 'bg-rose-600/10' };
  if (pts >= 2500) return { name: 'Grandmaster', color: 'text-purple-600', bg: 'bg-purple-600/10' };
  if (pts >= 1000) return { name: 'Elite', color: 'text-indigo-600', bg: 'bg-indigo-600/10' };
  if (pts >= 500) return { name: 'Scholar', color: 'text-emerald-600', bg: 'bg-emerald-600/10' };
  return { name: 'Aspirant', color: 'text-slate-500', bg: 'bg-slate-500/10' };
};

const App: React.FC = () => {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [userStats, setUserStats] = useState<UserStats>({ points: 0, badges: [], streak: 0, dailyStreak: 0, lastActivityDate: '', selectedBatch: 'Lakshya JEE 2026' });
  const [selectedSubjectId, setSelectedSubjectId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const [activeUploadContext, setActiveUploadContext] = useState<{ subjectId: string, chapterId: string, category: 'shortNotes' | 'classNotes' | 'formulaNotes' } | null>(null);
  const [lastCompletedChapterId, setLastCompletedChapterId] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState<string | null>(null); 
  const [isGlobalFocusMode, setIsGlobalFocusMode] = useState(false);
  const [isThemeTransitioning, setIsThemeTransitioning] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [toastType, setToastType] = useState<'points' | 'badge'>('points');
  
  const [chapterAnalysis, setChapterAnalysis] = useState<{ id: string, text: string } | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState<string | null>(null);

  const [orionInitialPrompt, setOrionInitialPrompt] = useState<string>('');
  const [autoStartOrionVoice, setAutoStartOrionVoice] = useState(false);
  const [isOrionVoiceActive, setIsOrionVoiceActive] = useState(false);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const recognitionRef = useRef<any>(null);

  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [viewerUrl, setViewerUrl] = useState<string | null>(null);
  const [viewerFileName, setViewerFileName] = useState<string | null>(null);

  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const savedTheme = localStorage.getItem('garuda_theme');
    if (savedTheme) return savedTheme === 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  const playSuccessChime = (isRankUp = false) => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 44100 });
      }
      const ctx = audioCtxRef.current;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(isRankUp ? 880 : 440, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(isRankUp ? 1760 : 880, ctx.currentTime + 0.1);
      
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.5);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.5);
    } catch (e) {}
  };

  const toggleTheme = () => {
    setIsThemeTransitioning(true);
    setIsDarkMode(prev => !prev);
    setTimeout(() => setIsThemeTransitioning(false), 600);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === '/' && document.activeElement !== searchInputRef.current) {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition && !isOrionVoiceActive) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((result: any) => result[0].transcript)
          .join('')
          .toLowerCase();

        if (transcript.includes('orion') || transcript.includes('hi orion') || transcript.includes('hey orion')) {
          recognition.stop();
          setActiveTab('orion');
          setAutoStartOrionVoice(true);
        }
      };

      recognition.onend = () => {
        if (!isOrionVoiceActive) {
          try { recognition.start(); } catch(e) {}
        }
      };

      recognitionRef.current = recognition;
      try {
        recognition.start();
      } catch (e) {}
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [activeTab, isOrionVoiceActive]);

  useEffect(() => {
    const root = window.document.documentElement;
    const body = window.document.body;
    if (isDarkMode) {
      root.classList.add('dark');
      body.classList.add('dark');
      root.style.colorScheme = 'dark';
      localStorage.setItem('garuda_theme', 'dark');
    } else {
      root.classList.remove('dark');
      body.classList.remove('dark');
      root.style.colorScheme = 'light';
      localStorage.setItem('garuda_theme', 'light');
    }
  }, [isDarkMode]);

  useEffect(() => {
    const saved = localStorage.getItem('garuda_study_tracker_data');
    const savedStats = localStorage.getItem('garuda_user_stats');
    
    if (savedStats) {
      const parsedStats = JSON.parse(savedStats);
      setUserStats({
        points: 0,
        badges: [],
        streak: 0,
        dailyStreak: 0,
        lastActivityDate: '',
        selectedBatch: 'Lakshya JEE 2026',
        ...parsedStats
      });
    }

    if (saved) {
      const parsed = JSON.parse(saved);
      const merged = INITIAL_SUBJECTS.map(initial => {
        const found = parsed.find((p: Subject) => p.id === initial.id);
        if (found) {
          return { 
            ...initial, 
            chapters: initial.chapters.map(initChap => {
              const savedChap = found.chapters.find((sc: any) => sc.id === initChap.id);
              if (savedChap) {
                return {
                  ...initChap,
                  ...savedChap,
                  shortNotes: Array.isArray(savedChap.shortNotes) ? savedChap.shortNotes : [],
                  classNotes: Array.isArray(savedChap.classNotes) ? savedChap.classNotes : [],
                  formulaNotes: Array.isArray(savedChap.formulaNotes) ? savedChap.formulaNotes : [],
                };
              }
              return initChap;
            }) 
          };
        }
        return initial;
      });
      setSubjects(merged);
    } else {
      setSubjects(INITIAL_SUBJECTS);
    }
  }, []);

  useEffect(() => {
    if (subjects.length > 0) {
      localStorage.setItem('garuda_study_tracker_data', JSON.stringify(subjects));
    }
    localStorage.setItem('garuda_user_stats', JSON.stringify(userStats));
  }, [subjects, userStats]);

  const triggerToast = (msg: string, type: 'points' | 'badge' = 'points') => {
    setToastMessage(msg);
    setToastType(type);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
  };

  const checkBadges = (updatedSubjects: Subject[], currentPoints: number) => {
    const unlocked = [...userStats.badges];
    let newlyUnlocked = false;

    const subjectsToTrack = [
      { id: 'maths', tiers: [{ t: 0.25, b: 'math_adept' }, { t: 0.5, b: 'math_wizard' }, { t: 1.0, b: 'math_apex' }] },
      { id: 'physics', tiers: [{ t: 0.25, b: 'phys_adept' }, { t: 0.5, b: 'phys_titan' }, { t: 1.0, b: 'phys_apex' }] },
      { id: 'chemistry', tiers: [{ t: 0.25, b: 'chem_adept' }, { t: 0.5, b: 'chem_catalyst' }, { t: 1.0, b: 'chem_apex' }] },
    ];

    subjectsToTrack.forEach(({ id, tiers }) => {
      const subject = updatedSubjects.find(s => s.id === id);
      if (subject) {
        const progress = subject.chapters.filter(c => c.isCompleted).length / subject.chapters.length;
        tiers.forEach(({ t, b }) => {
          if (progress >= t && !unlocked.includes(b)) {
            unlocked.push(b);
            newlyUnlocked = true;
            const badgeName = BADGES.find(badge => badge.id === b)?.name || 'Milestone';
            triggerToast(`Mastery Unlocked: ${badgeName}!`, 'badge');
          }
        });
      }
    });

    if (currentPoints >= 5000 && !unlocked.includes('garuda_vanguard')) {
      unlocked.push('garuda_vanguard');
      newlyUnlocked = true;
      triggerToast('Elite Status: Garuda Vanguard!', 'badge');
    }

    if (newlyUnlocked) {
      setUserStats(prev => ({ ...prev, badges: unlocked }));
      playSuccessChime(true);
    }
  };

  const toggleChapterComplete = (subjectId: string, chapterId: string) => {
    let pointDelta = 0;
    let nextSessionStreak = userStats.streak || 0;
    let nextDailyStreak = userStats.dailyStreak || 0;
    const todayStr = new Date().toISOString().split('T')[0];
    
    const updatedSubjects = subjects.map(subject => {
      if (subject.id === subjectId) {
        return {
          ...subject,
          chapters: subject.chapters.map(chapter => {
            if (chapter.id === chapterId) {
              const nextStatus = !chapter.isCompleted;
              
              if (nextStatus) {
                nextSessionStreak += 1;
                
                if (userStats.lastActivityDate !== todayStr) {
                  const yesterday = new Date();
                  yesterday.setDate(yesterday.getDate() - 1);
                  const yesterdayStr = yesterday.toISOString().split('T')[0];
                  
                  if (userStats.lastActivityDate === yesterdayStr) {
                    nextDailyStreak += 1;
                    triggerToast(`Daily Streak Increased! Day ${nextDailyStreak}`, 'badge');
                  } else {
                    nextDailyStreak = 1;
                    triggerToast(`Study Journey Resumed!`, 'badge');
                  }
                }

                const momentumBonus = Math.min((nextSessionStreak - 1) * 10, 50);
                const dailyMultiplier = 1 + (nextDailyStreak * 0.1); 
                pointDelta = Math.round((100 + momentumBonus) * dailyMultiplier);
                
                setLastCompletedChapterId(chapterId);
                triggerToast(`${pointDelta} GP Earned! Streak: ${nextDailyStreak} Days`, 'points');
                playSuccessChime();
                setTimeout(() => setLastCompletedChapterId(null), 2000); 
              } else {
                nextSessionStreak = 0;
                pointDelta = -100;
              }
              
              return { ...chapter, isCompleted: nextStatus };
            }
            return chapter;
          })
        };
      }
      return subject;
    });

    setSubjects(updatedSubjects);
    const newPoints = Math.max(0, userStats.points + pointDelta);
    
    const oldRank = getRank(userStats.points);
    const newRank = getRank(newPoints);
    if (newRank.name !== oldRank.name && newPoints > userStats.points) {
      triggerToast(`Rank Ascended: ${newRank.name}!`, 'badge');
      playSuccessChime(true);
    }

    setUserStats(prev => ({ 
      ...prev, 
      points: newPoints, 
      streak: nextSessionStreak,
      dailyStreak: nextDailyStreak,
      lastActivityDate: todayStr
    }));
    checkBadges(updatedSubjects, newPoints);
  };

  const handleDashboardAction = (subjectId: string, chapterId: string, action: string, subtask?: string) => {
    if (action === 'bucket') {
      setSelectedSubjectId(subjectId);
      setActiveTab('dashboard');
      setTimeout(() => {
        const el = document.getElementById(`chapter-${chapterId}`);
        el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 300);
    } else if (action === 'questions') {
      const subject = subjects.find(s => s.id === subjectId);
      const chapter = subject?.chapters.find(c => c.id === chapterId);
      if (chapter) {
        setOrionInitialPrompt(`Arnav, I've loaded your context for ${chapter.name} (${subject?.name}). Providing 5 elite practice questions now.`);
        setActiveTab('orion');
      }
    } else if (action === 'pw_lecture') {
      const subject = subjects.find(s => s.id === subjectId);
      const chapter = subject?.chapters.find(c => c.id === chapterId);
      if (chapter) {
        const cleanName = chapter.name.split(' — ')[0];
        const searchUrl = `https://www.pw.live/study/batches/${userStats.selectedBatch}/search?query=${encodeURIComponent(cleanName)}`;
        window.open(searchUrl, '_blank');
        triggerToast("Opening PW Hub...", "points");
      }
    } else if (action === 'toggle_subtask' && subtask) {
      setSubjects(prev => prev.map(s => {
        if (s.id === subjectId) {
          return {
            ...s,
            chapters: s.chapters.map(c => {
              if (c.id === chapterId) {
                const nextVal = !((c as any)[subtask]);
                if (nextVal) triggerToast("+10 GP Combat Bonus", "points");
                return { ...c, [subtask]: nextVal };
              }
              return c;
            })
          };
        }
        return s;
      }));
      setUserStats(prev => ({ ...prev, points: prev.points + 10 }));
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !activeUploadContext) return;
    const { subjectId, chapterId, category } = activeUploadContext;
    
    if (file.type !== 'application/pdf') {
      alert('Please upload a valid PDF file.');
      return;
    }
    const uploadKey = `${category}-${chapterId}`;
    setIsUploading(uploadKey);
    const fileId = `${Date.now()}`; 
    const studyFile: StudyFile = { id: fileId, name: file.name, timestamp: Date.now() };
    try {
      await saveFile(fileId, file);
      setSubjects(prev => prev.map(subject => {
        if (subject.id === subjectId) {
          return {
            ...subject,
            chapters: subject.chapters.map(chapter => {
              if (chapter.id === chapterId) {
                return { ...chapter, [category]: [...chapter[category], studyFile] };
              }
              return chapter;
            })
          };
        }
        return subject;
      }));
      triggerToast("+50 GP Resource Bonus", "points");
      setUserStats(prev => ({ ...prev, points: prev.points + 50 }));
    } catch (error) {
      alert('Failed to save file.');
    } finally {
      setIsUploading(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      setActiveUploadContext(null);
    }
  };

  const handleViewFile = async (fileId: string, fileName: string) => {
    const blob = await getFile(fileId);
    if (blob) {
      const url = URL.createObjectURL(blob);
      setViewerUrl(url);
      setViewerFileName(fileName);
      setIsViewerOpen(true);
    } else {
      alert('Resource not found.');
    }
  };

  const handleRemoveFile = async (subjectId: string, chapterId: string, category: keyof Chapter, fileId: string) => {
    if (!confirm('Permanently delete this resource?')) return;
    await deleteFile(fileId);
    setSubjects(prev => prev.map(subject => {
      if (subject.id === subjectId) {
        return {
          ...subject,
          chapters: subject.chapters.map(chapter => {
            if (chapter.id === chapterId) {
              const currentArray = chapter[category] as StudyFile[];
              return { ...chapter, [category]: currentArray.filter(f => f.id !== fileId) };
            }
            return chapter;
          })
        };
      }
      return subject;
    }));
  };

  const triggerUpload = (subjectId: string, chapterId: string, category: 'shortNotes' | 'classNotes' | 'formulaNotes') => {
    setActiveUploadContext({ subjectId, chapterId, category });
    fileInputRef.current?.click();
  };

  const filteredSubjects = useMemo(() => {
    if (!searchQuery.trim()) return subjects;
    const query = searchQuery.toLowerCase();
    return subjects.filter(s => 
      s.name.toLowerCase().includes(query) || 
      s.hindiName?.toLowerCase().includes(query) ||
      s.chapters.some(c => c.name.toLowerCase().includes(query))
    );
  }, [subjects, searchQuery]);

  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const query = searchQuery.toLowerCase();
    const results: { type: 'subject' | 'chapter', title: string, subtitle: string, subjectId: string, chapterId?: string }[] = [];
    
    subjects.forEach(s => {
      if (s.name.toLowerCase().includes(query)) {
        results.push({ type: 'subject', title: s.name, subtitle: s.hindiName || '', subjectId: s.id });
      }
      s.chapters.forEach(c => {
        if (c.name.toLowerCase().includes(query)) {
          results.push({ type: 'chapter', title: c.name, subtitle: `In ${s.name}`, subjectId: s.id, chapterId: c.id });
        }
      });
    });
    
    return results.slice(0, 8);
  }, [subjects, searchQuery]);

  const selectedSubject = useMemo(() => subjects.find(s => s.id === selectedSubjectId), [subjects, selectedSubjectId]);
  
  const totalProgress = useMemo(() => {
    if (subjects.length === 0) return 0;
    const totalChapters = subjects.reduce((acc, s) => acc + s.chapters.length, 0);
    const completedChapters = subjects.reduce((acc, s) => acc + s.chapters.filter(c => c.isCompleted).length, 0);
    return Math.round((completedChapters / totalChapters) * 100);
  }, [subjects]);

  const getProgressGradient = (p: number) => {
    if (p < 30) return 'from-rose-500 to-rose-600 shadow-rose-500/30';
    if (p < 70) return 'from-amber-400 to-amber-500 shadow-amber-500/30';
    return 'from-emerald-400 to-emerald-600 shadow-emerald-500/30';
  };

  const currentSubjectProgress = useMemo(() => {
    if (!selectedSubject) return 0;
    const total = selectedSubject.chapters.length || 1;
    const completed = selectedSubject.chapters.filter(c => c.isCompleted).length;
    return Math.round((completed / total) * 100);
  }, [selectedSubject]);

  const currentRank = useMemo(() => getRank(userStats.points), [userStats.points]);

  return (
    <div className={`min-h-screen transition-all duration-700 font-sans ${isDarkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      {isDarkMode && <GalaxyBackground progress={totalProgress} isFocusMode={isGlobalFocusMode} />}
      
      {showToast && (
        <div className={`fixed top-24 right-8 z-[100] animate-in slide-in-from-right-8 fade-in duration-300`}>
           <div className={`${toastType === 'badge' ? 'bg-amber-500' : 'bg-indigo-600'} text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border border-white/20`}>
              <i className={`fa-solid ${toastType === 'badge' ? 'fa-trophy' : 'fa-bolt'} text-xl`}></i>
              <span className="font-black tracking-widest text-sm uppercase">{toastMessage}</span>
           </div>
        </div>
      )}

      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={(tab) => { setActiveTab(tab); setSelectedSubjectId(null); setSearchQuery(''); }} 
        isOpen={isSidebarOpen} 
        setIsOpen={setIsSidebarOpen}
        userStats={userStats}
        availableBadges={BADGES}
      />

      <PDFViewerModal 
        isOpen={isViewerOpen} 
        onClose={() => {
          setIsViewerOpen(false);
          if (viewerUrl) URL.revokeObjectURL(viewerUrl);
          setViewerUrl(null);
        }} 
        fileUrl={viewerUrl} 
        fileName={viewerFileName} 
      />

      <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept="application/pdf" />

      <div className={`transition-all duration-300 min-h-screen ${isSidebarOpen ? 'lg:pl-72' : 'lg:pl-20'}`}>
        <header className="sticky top-0 z-50 glass-card border-b border-slate-200 dark:border-slate-800 px-4 md:px-6 py-3">
          <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-shrink-0">
              <button 
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 hover:text-[#D11217] transition-all"
              >
                <i className={`fa-solid ${isSidebarOpen ? 'fa-outdent' : 'fa-indent'}`}></i>
              </button>
              <div className="hidden xs:block">
                <h2 className="text-lg font-black text-slate-800 dark:text-white uppercase tracking-tighter leading-none">
                  {activeTab === 'dashboard' ? (selectedSubjectId ? selectedSubject?.name : 'Battle Desk') : activeTab}
                </h2>
                <div className={`text-[8px] font-black uppercase tracking-widest mt-1 ${currentRank.color}`}>
                  {userStats.selectedBatch} • {currentRank.name}
                </div>
              </div>
            </div>

            <div className="relative flex-1 max-w-xl group">
              <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
                <i className={`fa-solid fa-magnifying-glass text-xs transition-colors ${searchQuery ? 'text-[#D11217]' : 'text-slate-400'}`}></i>
              </div>
              <input 
                ref={searchInputRef}
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Target Search (Press / )"
                className="w-full bg-slate-100 dark:bg-slate-800/50 border border-transparent focus:border-indigo-500/30 rounded-2xl py-2.5 pl-11 pr-4 text-xs font-bold text-slate-800 dark:text-white placeholder-slate-400 transition-all focus:ring-4 focus:ring-indigo-500/5 outline-none"
              />
            </div>
            
            <div className="flex items-center gap-2 sm:gap-4 flex-shrink-0">
              <div className="hidden xs:flex items-center gap-2 bg-indigo-500/10 dark:bg-indigo-500/20 px-3 py-1.5 rounded-xl border border-indigo-500/20">
                <i className="fa-solid fa-bolt text-indigo-500 text-sm"></i>
                <span className="text-xs font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-tighter">
                  {userStats.points} GP
                </span>
              </div>

              <button
                onClick={toggleTheme}
                className={`w-9 h-9 rounded-xl shadow-sm flex items-center justify-center border transition-all group overflow-hidden ${isDarkMode ? 'bg-slate-800 text-[#FFB800] border-slate-700' : 'bg-white text-[#D11217] border-slate-100'}`}
              >
                <i key={isDarkMode ? 'dark' : 'light'} className={`fa-solid ${isDarkMode ? 'fa-moon' : 'fa-sun'} text-base theme-icon-enter group-hover:scale-110`}></i>
              </button>
            </div>
          </div>
        </header>

        <main className="relative z-10 max-w-6xl mx-auto px-4 md:px-6 py-6 md:py-10">
          {activeTab === 'dashboard' && (
            <>
              {!selectedSubjectId ? (
                <>
                  <div className="text-center mb-8 flex flex-col items-center animate-in fade-in zoom-in duration-500">
                    <Logo className="w-24 md:w-32 h-auto" hideText={false} tagline="Neural Mastery Hub" compact={true} />
                  </div>
                  
                  <div className="w-full max-w-2xl mx-auto mb-6 flex flex-col md:flex-row gap-4">
                    <div className="flex-1 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-6 rounded-[2rem] flex items-center gap-5 shadow-sm">
                      <div className="w-16 h-16 bg-rose-500 rounded-2xl flex items-center justify-center text-white text-3xl shadow-lg shadow-rose-500/20">
                         <i className="fa-solid fa-fire-flame-curved"></i>
                      </div>
                      <div>
                        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">PW Study Streak</h4>
                        <div className="flex items-baseline gap-2">
                           <span className="text-4xl font-black text-slate-900 dark:text-white">{userStats.dailyStreak || 0}</span>
                           <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase">Days</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex-1 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-6 rounded-[2rem] flex items-center gap-5 shadow-sm">
                      <div className="w-16 h-16 bg-indigo-500 rounded-2xl flex items-center justify-center text-white text-3xl shadow-lg shadow-indigo-500/20">
                         <i className="fa-solid fa-graduation-cap"></i>
                      </div>
                      <div>
                        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Active Batch</h4>
                        <div className="flex items-baseline gap-2">
                           <span className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tighter">{userStats.selectedBatch}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {!searchQuery && <CountdownTimer />}
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-6">
                    {filteredSubjects.map((subject, idx) => (
                      <div key={subject.id} className="animate-in fade-in slide-in-from-bottom-2 duration-300" style={{ animationDelay: `${idx * 40}ms` }}>
                        <SubjectCard subject={subject} onClick={() => setSelectedSubjectId(subject.id)} />
                      </div>
                    ))}
                  </div>
                  {!searchQuery && <ExamSchedule subjects={subjects} onChapterAction={handleDashboardAction} />}
                </>
              ) : (
                <div className="max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-500">
                  <button onClick={() => setSelectedSubjectId(null)} className="flex items-center gap-2 text-slate-500 hover:text-[#D11217] font-black text-[10px] uppercase tracking-widest mb-6 transition-colors group">
                    <i className="fa-solid fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
                    Return Dashboard
                  </button>

                  <div className="bg-white dark:bg-slate-900/60 rounded-[2.5rem] shadow-2xl border border-slate-100 dark:border-slate-800 overflow-hidden mb-8 backdrop-blur-xl">
                    <div className={`${selectedSubject?.color} p-6 md:p-10 text-white relative`}>
                      <div className="relative z-10">
                        <h2 className="text-3xl md:text-5xl font-black tracking-tighter uppercase leading-none">{selectedSubject?.name} Combat</h2>
                        <p className="text-white/80 font-bold text-base md:text-lg mt-1.5 tracking-wide">{selectedSubject?.hindiName}</p>
                      </div>
                    </div>
                    <div className="p-5 md:p-10">
                      <div className="space-y-6">
                        {selectedSubject?.chapters.map((chapter) => (
                          <div key={chapter.id} id={`chapter-${chapter.id}`} className={`p-5 rounded-[1.5rem] border transition-all duration-500 relative ${chapter.isCompleted ? 'bg-[#D11217]/5 border-[#D11217]/10' : 'bg-white dark:bg-slate-800/40 border-slate-100 dark:border-slate-800'}`}>
                            <div className="flex flex-col xl:flex-row xl:items-start justify-between gap-6">
                              <div className="flex-1">
                                <h5 className={`text-xl font-bold transition-all uppercase flex items-center gap-3 mb-6 ${chapter.isCompleted ? 'text-[#D11217] opacity-80' : 'text-slate-800 dark:text-slate-200'}`}>
                                  {chapter.name}
                                </h5>

                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                  <FileCategorySection title="PW Modules" files={chapter.shortNotes} isUploading={isUploading === `shortNotes-${chapter.id}`} onUpload={() => triggerUpload(selectedSubject.id, chapter.id, 'shortNotes')} onFileDrop={(file) => {}} onView={handleViewFile} onDelete={(fid) => handleRemoveFile(selectedSubject.id, chapter.id, 'shortNotes', fid)} />
                                  <FileCategorySection title="DPP Sheets" files={chapter.classNotes} isUploading={isUploading === `classNotes-${chapter.id}`} onUpload={() => triggerUpload(selectedSubject.id, chapter.id, 'classNotes')} onFileDrop={(file) => {}} onView={handleViewFile} onDelete={(fid) => handleRemoveFile(selectedSubject.id, chapter.id, 'classNotes', fid)} />
                                  <FileCategorySection title="Rev. Maps" files={chapter.formulaNotes} isUploading={isUploading === `formulaNotes-${chapter.id}`} onUpload={() => triggerUpload(selectedSubject.id, chapter.id, 'formulaNotes')} onFileDrop={(file) => {}} onView={handleViewFile} onDelete={(fid) => handleRemoveFile(selectedSubject.id, chapter.id, 'formulaNotes', fid)} />
                                </div>
                              </div>
                              <button onClick={() => toggleChapterComplete(selectedSubject.id, chapter.id)} className={`self-end xl:self-start flex items-center gap-2 px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${chapter.isCompleted ? 'bg-green-500 text-white shadow-lg shadow-green-500/20 active:scale-95' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700'}`}>
                                {chapter.isCompleted ? 'Mission Done' : 'Complete Mission'}
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}

          {activeTab === 'orion' && (
            <OrionAI 
              subjects={subjects} 
              userStats={userStats} 
              onToggleChapter={toggleChapterComplete} 
              onNavigate={setActiveTab} 
              initialPrompt={orionInitialPrompt} 
              autoStartVoice={autoStartOrionVoice}
              onVoiceStarted={() => setAutoStartOrionVoice(false)}
              onVoiceStatusChange={setIsOrionVoiceActive}
            />
          )}
          {activeTab === 'pomodoro' && <PomodoroTimer onCompleteSession={(p) => setUserStats(prev => ({ ...prev, points: prev.points + p }))} />}
          {activeTab === 'powernap' && <PowerNap onFocusStateChange={setIsGlobalFocusMode} />}
          {activeTab === 'test' && <TestSeries />}
          {activeTab === 'calculator' && <div className="py-6"><ScientificCalculator /></div>}
        </main>
        
        <footer className="mt-6 border-t border-slate-200 dark:border-slate-800 py-10 px-6 text-center">
          <Logo className="w-12 h-auto mx-auto mb-3" />
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.3em]">
            Developed with Integrity by Arnav Singh • 2026
          </p>
        </footer>
      </div>

      {/* Floating Orion Button */}
      {activeTab !== 'orion' && (
        <button 
          onClick={() => {
            setActiveTab('orion');
            setAutoStartOrionVoice(true);
          }}
          className="fixed bottom-8 right-8 z-[100] group"
        >
          <div className="absolute inset-0 bg-indigo-600 blur-2xl opacity-20 group-hover:opacity-40 transition-opacity"></div>
          <div className="relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-3 rounded-full shadow-2xl hover:scale-110 transition-transform active:scale-95">
            <OrionLogo className="w-12 h-12" />
            <div className="absolute -top-2 -right-2 bg-indigo-600 text-white text-[8px] font-black px-2 py-1 rounded-full uppercase tracking-widest animate-bounce">
              Wake Orion
            </div>
          </div>
        </button>
      )}
    </div>
  );
};

const FileCategorySection: React.FC<{ 
  title: string; 
  files: StudyFile[]; 
  isUploading: boolean;
  onUpload: () => void;
  onFileDrop: (file: File) => void;
  onView: (id: string, name: string) => void;
  onDelete: (id: string) => void;
}> = ({ title, files, isUploading, onUpload, onView, onDelete }) => {
  return (
    <div className={`relative group bg-slate-50 dark:bg-slate-900/40 rounded-2xl p-4 border-2 border-dashed transition-all duration-300 border-slate-100 dark:border-slate-800`}>
      <div className="flex items-center justify-between mb-3">
         <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">{title}</span>
         <button onClick={onUpload} className="w-6 h-6 rounded-lg bg-white dark:bg-slate-800 flex items-center justify-center text-indigo-500 shadow-sm hover:scale-110 active:scale-95 transition-transform"><i className="fa-solid fa-plus text-xs"></i></button>
      </div>
      <div className="space-y-2 max-h-[140px] overflow-y-auto pr-1 min-h-[60px]">
        {files.length === 0 ? <div className="h-full flex flex-col items-center justify-center py-4 text-slate-400 opacity-60"><i className="fa-solid fa-cloud-arrow-up text-xl mb-1.5"></i><p className="text-[8px] font-black uppercase tracking-[0.2em]">Drop PDF</p></div> : files.map(file => (
          <div key={file.id} onClick={() => onView(file.id, file.name)} className="flex items-center justify-between gap-2 bg-white dark:bg-slate-800 p-2 rounded-xl border border-slate-100 dark:border-slate-700 shadow-sm hover:border-indigo-500/30 transition-all cursor-pointer">
            <span className="text-[9px] font-bold truncate dark:text-slate-300">{file.name}</span>
            <button onClick={(e) => { e.stopPropagation(); onDelete(file.id); }} className="text-slate-400 hover:text-rose-500"><i className="fa-solid fa-trash text-[10px]"></i></button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
