
export interface StudyFile {
  id: string;
  name: string;
  timestamp: number;
}

export interface Chapter {
  id: string;
  name: string;
  category: string;
  isCompleted: boolean;
  // PW Integration tracking
  lectureDone?: boolean;
  dppDone?: boolean;
  moduleDone?: boolean;
  pwUrl?: string;
  
  shortNotes: StudyFile[];
  classNotes: StudyFile[];
  formulaNotes: StudyFile[];
}

export interface Subject {
  id: string;
  name: string;
  hindiName?: string;
  icon: string;
  color: string;
  chapters: Chapter[];
  examDate?: string;
}

export interface ExamCountdown {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export interface Badge {
  id: string;
  name: string;
  icon: string;
  color: string;
  description: string;
}

export interface UserStats {
  points: number;
  badges: string[]; // Array of badge IDs
  streak?: number; // Current session momentum streak
  dailyStreak?: number; // Consecutive days of activity
  lastActivityDate?: string; // YYYY-MM-DD
  selectedBatch?: string; // Current PW Batch
}
