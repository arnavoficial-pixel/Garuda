
import { Subject } from './types';

const initChapter = (id: string, name: string, category: string) => ({
  id,
  name,
  category,
  isCompleted: false,
  shortNotes: [],
  classNotes: [],
  formulaNotes: [],
});

export const INITIAL_SUBJECTS: Subject[] = [
  {
    id: 'physics',
    name: 'Physics',
    hindiName: '323 Lectures • Board + JEE Neural Mastery',
    icon: 'fa-bolt',
    color: 'bg-amber-500',
    examDate: '2026-04-03T09:00:00',
    chapters: [
      // Mechanics
      initChapter('p_units', 'Units & Dimensions — 14', 'Mechanics'),
      initChapter('p_maths', 'Basic Mathematics — 11', 'Mechanics'),
      initChapter('p_1d', 'Motion in 1D — 14', 'Mechanics'),
      initChapter('p_2d', 'Motion in Plane — 17', 'Mechanics'),
      initChapter('p_nlm', 'Laws of Motion — 17', 'Mechanics'),
      initChapter('p_wep', 'Work Energy Power — 13', 'Mechanics'),
      initChapter('p_circular', 'Circular Motion — 10', 'Mechanics'),
      initChapter('p_com', 'Centre of Mass — 14', 'Mechanics'),
      initChapter('p_rotation', 'Rotational Motion — 19', 'Mechanics'),
      initChapter('p_grav', 'Gravitation — 5', 'Mechanics'),
      initChapter('p_solid', 'Mechanical Properties of Solids — 12', 'Mechanics'),
      initChapter('p_fluid', 'Mechanical Properties of Fluids — 1', 'Mechanics'),
      // Thermal
      initChapter('p_thermal_prop', 'Thermal Properties of Matter — 7', 'Thermal Physics'),
      initChapter('p_ktg', 'Kinetic Theory of Gases — 6', 'Thermal Physics'),
      initChapter('p_thermo', 'Thermodynamics — 7', 'Thermal Physics'),
      // Waves
      initChapter('p_osc', 'Oscillations — 8', 'Oscillations & Waves'),
      initChapter('p_waves', 'Waves — 8', 'Oscillations & Waves'),
      // Electricity
      initChapter('p_charges', 'Electric Charges & Fields — 24', 'Electricity & Magnetism'),
      initChapter('p_potential', 'Electric Potential & Capacitance — 14', 'Electricity & Magnetism'),
      initChapter('p_current', 'Current Electricity — 15', 'Electricity & Magnetism'),
      initChapter('p_moving_charges', 'Moving Charges & Magnetism — 14', 'Electricity & Magnetism'),
      initChapter('p_mag_matter', 'Magnetism & Matter — 3', 'Electricity & Magnetism'),
      initChapter('p_emi', 'Electromagnetic Induction — 12', 'Electricity & Magnetism'),
      initChapter('p_ac', 'Alternating Current — 7', 'Electricity & Magnetism'),
      // Optics
      initChapter('p_ray_optics', 'Ray Optics — 21', 'Optics'),
      initChapter('p_wave_optics', 'Wave Optics — 8', 'Optics'),
      // Modern
      initChapter('p_dual', 'Dual Nature — 4', 'Modern Physics'),
      initChapter('p_atoms', 'Atoms — 3', 'Modern Physics'),
      initChapter('p_nuclei', 'Nuclei — 1', 'Modern Physics'),
      initChapter('p_semi', 'Semiconductors — 6', 'Modern Physics'),
      // Misc
      initChapter('p_instruments', 'Instruments — 2', 'Misc'),
      initChapter('p_extra', 'Extra Lectures — 6', 'Misc'),
    ]
  },
  {
    id: 'chemistry',
    name: 'Chemistry',
    hindiName: '279 Lectures • Atomic Combat Deck',
    icon: 'fa-flask',
    color: 'bg-emerald-500',
    examDate: '2026-04-05T09:00:00',
    chapters: [
      // Physical
      initChapter('c_mole', 'Mole Concept — 15', 'Physical Chemistry'),
      initChapter('c_atomic', 'Atomic Structure — 22', 'Physical Chemistry'),
      initChapter('c_states', 'States of Matter — 11', 'Physical Chemistry'),
      initChapter('c_thermo', 'Thermodynamics — 14', 'Physical Chemistry'),
      initChapter('c_equi', 'Equilibrium — 4', 'Physical Chemistry'),
      initChapter('c_ionic', 'Ionic Equilibrium — 8', 'Physical Chemistry'),
      initChapter('c_redox', 'Redox Reactions — 4', 'Physical Chemistry'),
      initChapter('c_sol', 'Solutions — 17', 'Physical Chemistry'),
      initChapter('c_electro', 'Electrochemistry — 12', 'Physical Chemistry'),
      initChapter('c_kinetic', 'Chemical Kinetics — 13', 'Physical Chemistry'),
      initChapter('c_solid', 'Solid State — 5', 'Physical Chemistry'),
      initChapter('c_surface', 'Surface Chemistry — 1', 'Physical Chemistry'),
      // Organic
      initChapter('c_iupac', 'IUPAC — 10', 'Organic Chemistry'),
      initChapter('c_goc', 'General Organic Chemistry — 13', 'Organic Chemistry'),
      initChapter('c_iso', 'Isomerism — 11', 'Organic Chemistry'),
      initChapter('c_hydro', 'Hydrocarbons — 6', 'Organic Chemistry'),
      initChapter('c_halo', 'Haloalkanes & Haloarenes — 14', 'Organic Chemistry'),
      initChapter('c_alcohol', 'Alcohols Phenols Ethers — 7', 'Organic Chemistry'),
      initChapter('c_ald_ket', 'Aldehydes & Ketones — 6', 'Organic Chemistry'),
      initChapter('c_amines', 'Amines — 3', 'Organic Chemistry'),
      initChapter('c_biomol', 'Biomolecules — 4', 'Organic Chemistry'),
      initChapter('c_poly', 'Polymers — 1', 'Organic Chemistry'),
      initChapter('c_daily', 'Chemistry in Everyday Life — 2', 'Organic Chemistry'),
      initChapter('c_env', 'Environmental Chemistry — 1', 'Organic Chemistry'),
      initChapter('c_purif', 'Purification of Organic Compounds — 2', 'Organic Chemistry'),
      // Inorganic
      initChapter('c_periodic', 'Periodic Table — 12', 'Inorganic Chemistry'),
      initChapter('c_bonding', 'Chemical Bonding — 20', 'Inorganic Chemistry'),
      initChapter('c_sblock', 'S-Block — 3', 'Inorganic Chemistry'),
      initChapter('c_pblock', 'P-Block — 8', 'Inorganic Chemistry'),
      initChapter('c_hydrogen', 'Hydrogen — 1', 'Inorganic Chemistry'),
      initChapter('c_coordination', 'Coordination Compounds — 15', 'Inorganic Chemistry'),
      initChapter('c_dfblock', 'D & F Block — 6', 'Inorganic Chemistry'),
      initChapter('c_metallurgy', 'Metallurgy — 1', 'Inorganic Chemistry'),
      initChapter('c_salt', 'Salt Analysis — 7', 'Inorganic Chemistry'),
    ]
  },
  {
    id: 'maths',
    name: 'Mathematics',
    hindiName: '255 Lectures • Logic Dominance',
    icon: 'fa-calculator',
    color: 'bg-blue-600',
    examDate: '2026-04-01T09:00:00',
    chapters: [
      // Functions
      initChapter('m_relations', 'Relations — 3', 'Calculus & Functions'),
      initChapter('m_func', 'Relations & Functions — 26', 'Calculus & Functions'),
      // Trigonometry
      initChapter('m_trig_func', 'Trigonometric Functions — 10', 'Trigonometry'),
      initChapter('m_trig_eq', 'Trigonometric Equations — 4', 'Trigonometry'),
      initChapter('m_sot', 'Solution of Triangle — 4', 'Trigonometry'),
      // Algebra
      initChapter('m_quad', 'Quadratic Equations — 11', 'Algebra'),
      initChapter('m_seq', 'Sequence & Series — 10', 'Algebra'),
      initChapter('m_binomial', 'Binomial Theorem — 8', 'Algebra'),
      initChapter('m_complex', 'Complex Numbers — 12', 'Algebra'),
      initChapter('m_pnc', 'Permutations & Combinations — 11', 'Algebra'),
      initChapter('m_matrices', 'Matrices — 14', 'Algebra'),
      initChapter('m_det', 'Determinants — 10', 'Algebra'),
      // Coordinate
      initChapter('m_lines', 'Straight Lines — 13', 'Coordinate Geometry'),
      initChapter('m_circles', 'Circles — 10', 'Coordinate Geometry'),
      initChapter('m_parabola', 'Parabola — 9', 'Coordinate Geometry'),
      initChapter('m_ellipse', 'Ellipse — 6', 'Coordinate Geometry'),
      initChapter('m_hyperbola', 'Hyperbola — 5', 'Coordinate Geometry'),
      // Calculus Continued
      initChapter('m_limits', 'Limits — 6', 'Calculus & Functions'),
      initChapter('m_continuity', 'Continuity — 15', 'Calculus & Functions'),
      initChapter('m_diff_ability', 'Differentiability — 6', 'Calculus & Functions'),
      initChapter('m_indefinite', 'Indefinite Integration — 8', 'Calculus & Functions'),
      initChapter('m_definite', 'Definite Integration — 10', 'Calculus & Functions'),
      initChapter('m_aoi', 'Application of Integrals — 5', 'Calculus & Functions'),
      initChapter('m_diff_eq', 'Differential Equations — 7', 'Calculus & Functions'),
      // Vector
      initChapter('m_vectors', 'Vector Algebra — 10', 'Vector & 3D'),
      initChapter('m_3d', '3D Geometry — 5', 'Vector & 3D'),
      // Probability
      initChapter('m_prob', 'Probability — 12', 'Probability & Stats'),
      initChapter('m_stats', 'Statistics — 4', 'Probability & Stats'),
    ]
  }
];
